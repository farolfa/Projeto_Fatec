import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Switch } from "../components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { User, Bell, Lock, MapPin, Mail, Phone, Calendar } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { useState } from "react";

export function Perfil() {
  const [notifications, setNotifications] = useState({
    email: true,
    sms: false,
    push: true,
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold mb-2">Meu Perfil</h1>
          <p className="text-blue-100">Gerencie suas informações e preferências</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Profile Header */}
        <Card className="p-6 mb-6">
          <div className="flex items-center gap-6">
            <div className="relative">
              <div className="w-24 h-24 rounded-full overflow-hidden bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white text-4xl font-bold">
                JS
              </div>
              <Button
                size="sm"
                className="absolute bottom-0 right-0 rounded-full w-8 h-8 p-0 bg-orange-500 hover:bg-orange-600"
              >
                ✏️
              </Button>
            </div>
            <div className="flex-1">
              <h2 className="text-2xl font-bold mb-1">João Silva</h2>
              <p className="text-gray-600 mb-2">Membro desde Março 2026</p>
              <div className="flex gap-2">
                <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                  ✓ Email Verificado
                </span>
                <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                  5 Serviços Realizados
                </span>
              </div>
            </div>
          </div>
        </Card>

        {/* Tabs */}
        <Tabs defaultValue="personal" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="personal">
              <User className="mr-2" size={18} />
              Dados Pessoais
            </TabsTrigger>
            <TabsTrigger value="notifications">
              <Bell className="mr-2" size={18} />
              Notificações
            </TabsTrigger>
            <TabsTrigger value="security">
              <Lock className="mr-2" size={18} />
              Segurança
            </TabsTrigger>
          </TabsList>

          {/* Personal Data */}
          <TabsContent value="personal">
            <Card className="p-6">
              <h3 className="text-xl font-bold mb-6">Informações Pessoais</h3>
              <form className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">Nome</Label>
                    <Input id="firstName" defaultValue="João" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Sobrenome</Label>
                    <Input id="lastName" defaultValue="Silva" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">
                    <Mail className="inline mr-2" size={16} />
                    E-mail
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    defaultValue="joao.silva@email.com"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="phone">
                      <Phone className="inline mr-2" size={16} />
                      Telefone
                    </Label>
                    <Input id="phone" defaultValue="(11) 98765-4321" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="birthdate">
                      <Calendar className="inline mr-2" size={16} />
                      Data de Nascimento
                    </Label>
                    <Input id="birthdate" type="date" defaultValue="1990-05-15" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">
                    <MapPin className="inline mr-2" size={16} />
                    Endereço
                  </Label>
                  <Input
                    id="address"
                    defaultValue="Rua das Flores, 123, São Paulo - SP"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="cep">CEP</Label>
                  <Input id="cep" defaultValue="01234-567" className="w-48" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bio">Sobre você</Label>
                  <Textarea
                    id="bio"
                    rows={4}
                    placeholder="Conte um pouco sobre você..."
                    defaultValue="Gosto de manter minha casa sempre em ordem e valorizo profissionais de qualidade."
                  />
                </div>

                <div className="flex gap-3 pt-4">
                  <Button className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800">
                    Salvar Alterações
                  </Button>
                  <Button variant="outline">Cancelar</Button>
                </div>
              </form>
            </Card>
          </TabsContent>

          {/* Notifications */}
          <TabsContent value="notifications">
            <Card className="p-6">
              <h3 className="text-xl font-bold mb-6">Preferências de Notificações</h3>
              
              <div className="space-y-6">
                <div>
                  <h4 className="font-semibold mb-4">Como deseja receber notificações?</h4>
                  
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <div className="font-medium mb-1">E-mail</div>
                        <div className="text-sm text-gray-600">
                          Receba atualizações por e-mail
                        </div>
                      </div>
                      <Switch
                        checked={notifications.email}
                        onCheckedChange={(checked) =>
                          setNotifications({ ...notifications, email: checked })
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <div className="font-medium mb-1">SMS</div>
                        <div className="text-sm text-gray-600">
                          Receba alertas importantes por SMS
                        </div>
                      </div>
                      <Switch
                        checked={notifications.sms}
                        onCheckedChange={(checked) =>
                          setNotifications({ ...notifications, sms: checked })
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <div className="font-medium mb-1">Notificações Push</div>
                        <div className="text-sm text-gray-600">
                          Receba notificações no navegador
                        </div>
                      </div>
                      <Switch
                        checked={notifications.push}
                        onCheckedChange={(checked) =>
                          setNotifications({ ...notifications, push: checked })
                        }
                      />
                    </div>
                  </div>
                </div>

                <div className="border-t pt-6">
                  <h4 className="font-semibold mb-4">O que você deseja receber?</h4>
                  
                  <div className="space-y-3">
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input type="checkbox" defaultChecked className="w-4 h-4" />
                      <span className="text-sm">Novos orçamentos recebidos</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input type="checkbox" defaultChecked className="w-4 h-4" />
                      <span className="text-sm">Mensagens de profissionais</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input type="checkbox" defaultChecked className="w-4 h-4" />
                      <span className="text-sm">Status do pedido atualizado</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input type="checkbox" className="w-4 h-4" />
                      <span className="text-sm">Promoções e novidades</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input type="checkbox" className="w-4 h-4" />
                      <span className="text-sm">Newsletter semanal</span>
                    </label>
                  </div>
                </div>

                <div className="flex gap-3 pt-4">
                  <Button className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800">
                    Salvar Preferências
                  </Button>
                </div>
              </div>
            </Card>
          </TabsContent>

          {/* Security */}
          <TabsContent value="security">
            <Card className="p-6">
              <h3 className="text-xl font-bold mb-6">Segurança da Conta</h3>
              
              <div className="space-y-6">
                <div>
                  <h4 className="font-semibold mb-4">Alterar Senha</h4>
                  <form className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="currentPassword">Senha Atual</Label>
                      <Input id="currentPassword" type="password" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="newPassword">Nova Senha</Label>
                      <Input id="newPassword" type="password" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="confirmPassword">Confirmar Nova Senha</Label>
                      <Input id="confirmPassword" type="password" />
                    </div>
                    <Button className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800">
                      Atualizar Senha
                    </Button>
                  </form>
                </div>

                <div className="border-t pt-6">
                  <h4 className="font-semibold mb-4">Autenticação em Dois Fatores</h4>
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                    <p className="text-sm text-blue-900">
                      Adicione uma camada extra de segurança à sua conta ativando a
                      autenticação em dois fatores.
                    </p>
                  </div>
                  <Button variant="outline">Ativar 2FA</Button>
                </div>

                <div className="border-t pt-6">
                  <h4 className="font-semibold mb-4 text-red-600">Zona de Perigo</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-4 bg-red-50 border border-red-200 rounded-lg">
                      <div>
                        <div className="font-medium mb-1">Desativar Conta</div>
                        <div className="text-sm text-gray-600">
                          Desative temporariamente sua conta
                        </div>
                      </div>
                      <Button variant="outline" className="text-red-600 border-red-300">
                        Desativar
                      </Button>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-red-50 border border-red-200 rounded-lg">
                      <div>
                        <div className="font-medium mb-1">Excluir Conta</div>
                        <div className="text-sm text-gray-600">
                          Exclua permanentemente sua conta e dados
                        </div>
                      </div>
                      <Button variant="destructive">Excluir</Button>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
