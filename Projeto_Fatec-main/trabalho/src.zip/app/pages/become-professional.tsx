import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Textarea } from "../components/ui/textarea";
import { Label } from "../components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import { Checkbox } from "../components/ui/checkbox";
import { useState } from "react";
import {
  CheckCircle,
  DollarSign,
  Calendar,
  TrendingUp,
  Shield,
  Users,
  Star,
} from "lucide-react";

const categories = [
  "Reparos e Reformas",
  "Limpeza",
  "Eletricista",
  "Encanador",
  "Personal Trainer",
  "Pintura",
  "Mudanças",
  "Estética e Beleza",
  "Aulas Particulares",
  "Fotografia",
  "Jardinagem",
  "TI e Tecnologia",
];

const benefits = [
  {
    icon: DollarSign,
    title: "Aumente sua renda",
    description:
      "Receba pedidos de serviço todos os dias e aumente seus ganhos",
  },
  {
    icon: Calendar,
    title: "Flexibilidade total",
    description: "Você escolhe quando e onde trabalhar, sem compromissos fixos",
  },
  {
    icon: TrendingUp,
    title: "Cresça seu negócio",
    description:
      "Conquiste novos clientes e expanda sua base de forma consistente",
  },
  {
    icon: Shield,
    title: "Segurança e confiança",
    description: "Plataforma segura com sistema de avaliações e pagamentos",
  },
  {
    icon: Users,
    title: "Mais clientes",
    description: "Acesso a milhares de pessoas procurando seus serviços",
  },
  {
    icon: Star,
    title: "Construa reputação",
    description: "Sistema de avaliações para destacar seu trabalho de qualidade",
  },
];

export function BecomeProfessional() {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    categories: [] as string[],
    experience: "",
    description: "",
    city: "",
    state: "",
    acceptTerms: false,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const handleChange = (field: string, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const toggleCategory = (category: string) => {
    setFormData((prev) => ({
      ...prev,
      categories: prev.categories.includes(category)
        ? prev.categories.filter((c) => c !== category)
        : [...prev.categories, category],
    }));
  };

  if (submitted) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center px-4">
        <div className="max-w-md w-full text-center">
          <div className="bg-green-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="text-green-600" size={48} />
          </div>
          <h1 className="text-3xl mb-4">Cadastro Enviado!</h1>
          <p className="text-gray-600 mb-8">
            Parabéns! Seu cadastro foi recebido com sucesso. Nossa equipe irá
            analisar suas informações e entrar em contato em breve.
          </p>
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
            <h3 className="font-semibold mb-2">Próximos Passos:</h3>
            <ul className="text-left space-y-2 text-sm text-gray-700">
              <li>✓ Análise do cadastro (até 48h)</li>
              <li>✓ Verificação de documentos</li>
              <li>✓ Ativação da conta</li>
              <li>✓ Comece a receber pedidos!</li>
            </ul>
          </div>
          <p className="text-sm text-gray-500">
            Você receberá um e-mail com mais informações em até 48 horas.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 text-white py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDE2djQuMDFIMjB2LTRoMTZ6bTAgOHY0LjAxSDIwdi00aDE2em0wIDh2NC4wMUgyMHYtNGgxNnoiLz48L2c+PC9nPjwvc3ZnPg==')] opacity-30"></div>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <div className="inline-block mb-6">
            <span className="bg-orange-500 text-white px-4 py-2 rounded-full text-sm font-semibold uppercase tracking-wide shadow-lg">
              💰 Transforme Seu Talento em Renda
            </span>
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl mb-4 font-bold">
            Seja um Profissional<br />
            <span className="text-orange-400">FazTudoJA</span>
          </h1>
          <p className="text-xl md:text-2xl text-blue-100 mb-8">
            Cadastre-se <span className="text-white font-bold">GRÁTIS</span> e comece a receber pedidos <span className="text-orange-300 font-bold">HOJE MESMO</span>
          </p>
          <div className="grid md:grid-cols-3 gap-6 text-left">
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl border-2 border-white/20 hover:border-orange-400 transition-all">
              <div className="text-4xl mb-3">✨</div>
              <h3 className="font-bold text-lg mb-2">100% Grátis</h3>
              <p className="text-sm text-blue-100">
                Sem mensalidades ou taxas de cadastro
              </p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl border-2 border-white/20 hover:border-orange-400 transition-all">
              <div className="text-4xl mb-3">🚀</div>
              <h3 className="font-bold text-lg mb-2">Rápido e Fácil</h3>
              <p className="text-sm text-blue-100">
                Cadastro em menos de 5 minutos
              </p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl border-2 border-white/20 hover:border-orange-400 transition-all">
              <div className="text-4xl mb-3">💰</div>
              <h3 className="font-bold text-lg mb-2">Mais Trabalho</h3>
              <p className="text-sm text-blue-100">
                Acesso a milhares de clientes
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl md:text-5xl text-center mb-4 font-bold">
            Por que se cadastrar?
          </h2>
          <p className="text-center text-gray-600 mb-12 text-lg max-w-2xl mx-auto">
            Junte-se aos <span className="text-orange-600 font-bold">50 mil profissionais</span> que já estão faturando com a gente
          </p>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {benefits.map((benefit, index) => (
              <div key={index} className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow border-2 border-transparent hover:border-orange-400">
                <div className="bg-gradient-to-br from-blue-500 to-blue-700 w-16 h-16 rounded-2xl flex items-center justify-center mb-6 shadow-md">
                  <benefit.icon className="text-white" size={28} />
                </div>
                <h3 className="text-2xl font-bold mb-3">{benefit.title}</h3>
                <p className="text-gray-600 text-lg">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Registration Form */}
      <section className="py-16 bg-white">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <div className="inline-block mb-4">
              <span className="bg-gradient-to-r from-orange-500 to-orange-600 text-white px-4 py-2 rounded-full text-sm font-semibold uppercase tracking-wide shadow-lg">
                🎯 Comece Agora
              </span>
            </div>
            <h2 className="text-4xl md:text-5xl mb-4 font-bold bg-gradient-to-r from-blue-600 to-orange-500 bg-clip-text text-transparent">
              Faça seu Cadastro
            </h2>
            <p className="text-gray-600 text-lg">
              Preencha os dados e comece a receber pedidos <span className="text-orange-600 font-bold">em até 48h</span>
            </p>
          </div>

          <form
            onSubmit={handleSubmit}
            className="space-y-6 bg-white p-8 rounded-lg shadow-lg"
          >
            {/* Personal Info */}
            <div className="space-y-2">
              <Label htmlFor="name">Nome Completo *</Label>
              <Input
                id="name"
                type="text"
                placeholder="Seu nome completo"
                value={formData.name}
                onChange={(e) => handleChange("name", e.target.value)}
                required
              />
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="email">E-mail *</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="seu@email.com"
                  value={formData.email}
                  onChange={(e) => handleChange("email", e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Telefone/WhatsApp *</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="(11) 98765-4321"
                  value={formData.phone}
                  onChange={(e) => handleChange("phone", e.target.value)}
                  required
                />
              </div>
            </div>

            {/* Categories */}
            <div className="space-y-2">
              <Label>Categorias de Serviços que Oferece *</Label>
              <p className="text-sm text-gray-500 mb-3">
                Selecione todas que se aplicam
              </p>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {categories.map((category) => (
                  <div key={category} className="flex items-center space-x-2">
                    <Checkbox
                      id={category}
                      checked={formData.categories.includes(category)}
                      onCheckedChange={() => toggleCategory(category)}
                    />
                    <label
                      htmlFor={category}
                      className="text-sm cursor-pointer"
                    >
                      {category}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            {/* Experience */}
            <div className="space-y-2">
              <Label htmlFor="experience">Tempo de Experiência *</Label>
              <Select
                value={formData.experience}
                onValueChange={(value) => handleChange("experience", value)}
              >
                <SelectTrigger id="experience">
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0-1">Menos de 1 ano</SelectItem>
                  <SelectItem value="1-3">1 a 3 anos</SelectItem>
                  <SelectItem value="3-5">3 a 5 anos</SelectItem>
                  <SelectItem value="5-10">5 a 10 anos</SelectItem>
                  <SelectItem value="10+">Mais de 10 anos</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Description */}
            <div className="space-y-2">
              <Label htmlFor="description">
                Conte sobre você e seus serviços *
              </Label>
              <Textarea
                id="description"
                placeholder="Descreva sua experiência, especialidades e diferenciais..."
                value={formData.description}
                onChange={(e) => handleChange("description", e.target.value)}
                rows={5}
                required
              />
            </div>

            {/* Location */}
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="city">Cidade de Atuação *</Label>
                <Input
                  id="city"
                  type="text"
                  placeholder="Sua cidade"
                  value={formData.city}
                  onChange={(e) => handleChange("city", e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="state">Estado *</Label>
                <Input
                  id="state"
                  type="text"
                  placeholder="UF"
                  value={formData.state}
                  onChange={(e) => handleChange("state", e.target.value)}
                  required
                  maxLength={2}
                />
              </div>
            </div>

            {/* Terms */}
            <div className="flex items-start space-x-2">
              <Checkbox
                id="terms"
                checked={formData.acceptTerms}
                onCheckedChange={(checked) =>
                  handleChange("acceptTerms", checked)
                }
                required
              />
              <label htmlFor="terms" className="text-sm text-gray-600">
                Aceito os Termos de Uso e Política de Privacidade. Autorizo o
                compartilhamento dos meus dados com clientes interessados em
                meus serviços.
              </label>
            </div>

            {/* Submit */}
            <div className="pt-4">
              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-lg py-6 shadow-md"
                disabled={!formData.acceptTerms}
              >
                Cadastrar como Profissional
              </Button>
            </div>
          </form>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gradient-to-br from-orange-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl text-center mb-4 font-bold">
            Junte-se a milhares de profissionais
          </h2>
          <p className="text-center text-gray-600 mb-12 text-lg">
            Veja os resultados de quem já está na plataforma
          </p>
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div className="bg-white p-8 rounded-2xl shadow-lg">
              <div className="text-5xl font-bold bg-gradient-to-r from-blue-600 to-orange-500 bg-clip-text text-transparent mb-3">50k+</div>
              <p className="text-gray-600 text-lg font-medium">Profissionais cadastrados</p>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-lg">
              <div className="text-5xl font-bold bg-gradient-to-r from-blue-600 to-orange-500 bg-clip-text text-transparent mb-3">R$ 3.500</div>
              <p className="text-gray-600 text-lg font-medium">Ganho médio mensal</p>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-lg">
              <div className="text-5xl font-bold bg-gradient-to-r from-blue-600 to-orange-500 bg-clip-text text-transparent mb-3">4.8/5</div>
              <p className="text-gray-600 text-lg font-medium">Satisfação dos profissionais</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}