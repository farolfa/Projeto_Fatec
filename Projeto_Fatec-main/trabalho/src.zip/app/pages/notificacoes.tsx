import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import {
  Bell,
  MessageSquare,
  CheckCircle,
  AlertCircle,
  Star,
  DollarSign,
  Settings,
} from "lucide-react";
import { useState } from "react";

const notifications = [
  {
    id: 1,
    type: "proposal",
    title: "Novo orçamento recebido",
    message: "Carlos Silva enviou um orçamento de R$ 180 para Instalação de Chuveiro Elétrico",
    time: "Há 5 minutos",
    read: false,
    icon: DollarSign,
    color: "orange",
  },
  {
    id: 2,
    type: "message",
    title: "Nova mensagem",
    message: "Maria Oliveira: Olá! Quando seria o melhor horário para fazer a limpeza?",
    time: "Há 1 hora",
    read: false,
    icon: MessageSquare,
    color: "blue",
  },
  {
    id: 3,
    type: "review",
    title: "Pedido de avaliação",
    message: "Avalie o serviço de Pintura concluído por Roberto Santos",
    time: "Há 2 horas",
    read: false,
    icon: Star,
    color: "yellow",
  },
  {
    id: 4,
    type: "status",
    title: "Status atualizado",
    message: "Seu pedido de Conserto de Vazamento recebeu 3 novos orçamentos",
    time: "Há 5 horas",
    read: true,
    icon: CheckCircle,
    color: "green",
  },
  {
    id: 5,
    type: "alert",
    title: "Lembrete",
    message: "Você tem um serviço agendado para amanhã às 14h - Instalação de Chuveiro",
    time: "Ontem",
    read: true,
    icon: AlertCircle,
    color: "red",
  },
  {
    id: 6,
    type: "proposal",
    title: "Orçamento aceito",
    message: "Parabéns! O profissional confirmou o serviço para 05/03 às 9h",
    time: "Há 2 dias",
    read: true,
    icon: CheckCircle,
    color: "green",
  },
];

export function Notificacoes() {
  const [filter, setFilter] = useState<"all" | "unread">("all");
  const unreadCount = notifications.filter((n) => !n.read).length;

  const filteredNotifications =
    filter === "all"
      ? notifications
      : notifications.filter((n) => !n.read);

  const getIconColor = (color: string) => {
    const colors = {
      orange: "bg-orange-100 text-orange-600",
      blue: "bg-blue-100 text-blue-600",
      yellow: "bg-yellow-100 text-yellow-600",
      green: "bg-green-100 text-green-600",
      red: "bg-red-100 text-red-600",
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white py-8 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDE2djQuMDFIMjB2LTRoMTZ6bTAgOHY0LjAxSDIwdi00aDE2em0wIDh2NC4wMUgyMHYtNGgxNnoiLz48L2c+PC9nPjwvc3ZnPg==')] opacity-30"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Bell size={40} />
              <div>
                <h1 className="text-3xl font-bold mb-1">Notificações</h1>
                <p className="text-blue-100">
                  Você tem{" "}
                  <span className="font-bold text-orange-300">
                    {unreadCount}
                  </span>{" "}
                  {unreadCount === 1 ? "notificação nova" : "notificações novas"}
                </p>
              </div>
            </div>
            <Button
              variant="outline"
              className="bg-white/10 border-white/30 text-white hover:bg-white/20"
            >
              <Settings className="mr-2" size={18} />
              Configurações
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Filter Buttons */}
        <div className="flex gap-3 mb-6">
          <Button
            onClick={() => setFilter("all")}
            variant={filter === "all" ? "default" : "outline"}
            className={
              filter === "all"
                ? "bg-gradient-to-r from-blue-600 to-blue-700"
                : ""
            }
          >
            Todas ({notifications.length})
          </Button>
          <Button
            onClick={() => setFilter("unread")}
            variant={filter === "unread" ? "default" : "outline"}
            className={
              filter === "unread"
                ? "bg-gradient-to-r from-orange-500 to-orange-600"
                : ""
            }
          >
            Não Lidas ({unreadCount})
          </Button>
          <Button variant="ghost" className="ml-auto text-blue-600">
            Marcar todas como lidas
          </Button>
        </div>

        {/* Notifications List */}
        <div className="space-y-3">
          {filteredNotifications.map((notification) => (
            <Card
              key={notification.id}
              className={`p-5 hover:shadow-lg transition-all cursor-pointer border-l-4 ${
                !notification.read
                  ? "border-l-orange-500 bg-orange-50/30"
                  : "border-l-transparent"
              }`}
            >
              <div className="flex items-start gap-4">
                {/* Icon */}
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${getIconColor(
                    notification.color
                  )}`}
                >
                  <notification.icon size={24} />
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <h3
                      className={`font-semibold ${
                        !notification.read ? "text-gray-900" : "text-gray-700"
                      }`}
                    >
                      {notification.title}
                    </h3>
                    {!notification.read && (
                      <Badge className="bg-orange-500 text-white text-xs px-2">
                        NOVA
                      </Badge>
                    )}
                  </div>
                  <p className="text-gray-600 text-sm mb-2">
                    {notification.message}
                  </p>
                  <p className="text-gray-500 text-xs">{notification.time}</p>
                </div>

                {/* Actions */}
                <div className="flex flex-col gap-2">
                  {!notification.read && (
                    <Button size="sm" variant="ghost" className="text-xs">
                      Marcar como lida
                    </Button>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Empty State */}
        {filteredNotifications.length === 0 && (
          <Card className="p-12 text-center">
            <Bell className="mx-auto text-gray-400 mb-4" size={64} />
            <h3 className="text-xl font-semibold mb-2">
              Nenhuma notificação
            </h3>
            <p className="text-gray-600">
              Você não tem notificações{" "}
              {filter === "unread" ? "não lidas" : ""} no momento
            </p>
          </Card>
        )}
      </div>
    </div>
  );
}
