import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Avatar } from "../components/ui/avatar";
import { Badge } from "../components/ui/badge";
import {
  Star,
  MapPin,
  Calendar,
  MessageSquare,
  CheckCircle,
  Clock,
  Award,
} from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

const proposals = [
  {
    id: 1,
    requestTitle: "Instalação de Chuveiro Elétrico",
    professional: {
      name: "Carlos Silva",
      photo: "https://images.unsplash.com/photo-1556745753-b2904692b3cd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBzZXJ2aWNlJTIwd29ya2VyJTIwaGFwcHl8ZW58MXx8fHwxNzcyNDk4MTE4fDA&ixlib=rb-4.1.0&q=80&w=1080",
      rating: 4.9,
      reviews: 127,
      completedJobs: 156,
      verified: true,
    },
    price: "R$ 180,00",
    description:
      "Faço instalação de chuveiro elétrico com garantia de 90 dias. Trabalho com materiais de qualidade e tenho mais de 10 anos de experiência.",
    deliveryTime: "Amanhã, 04/03",
    location: "3.2 km de você",
    warranty: "90 dias",
    status: "pending",
  },
  {
    id: 2,
    requestTitle: "Instalação de Chuveiro Elétrico",
    professional: {
      name: "Roberto Santos",
      photo: "https://images.unsplash.com/photo-1672748341520-6a839e6c05bb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25zdHJ1Y3Rpb24lMjB3b3JrZXIlMjBzbWlsaW5nfGVufDF8fHx8MTc3MjQzNjY0OHww&ixlib=rb-4.1.0&q=80&w=1080",
      rating: 4.8,
      reviews: 93,
      completedJobs: 102,
      verified: true,
    },
    price: "R$ 150,00",
    description:
      "Eletricista profissional com certificação. Instalação rápida e segura. Atendo toda região de São Paulo.",
    deliveryTime: "Hoje, 03/03",
    location: "5.8 km de você",
    warranty: "60 dias",
    status: "pending",
  },
  {
    id: 3,
    requestTitle: "Instalação de Chuveiro Elétrico",
    professional: {
      name: "Eduardo Lima",
      photo: "https://images.unsplash.com/photo-1763865454676-49c131929996?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob21lJTIwcmVwYWlyJTIwc2VydmljZXN8ZW58MXx8fHwxNzcyNDk1OTQ4fDA&ixlib=rb-4.1.0&q=80&w=1080",
      rating: 5.0,
      reviews: 84,
      completedJobs: 89,
      verified: true,
    },
    price: "R$ 220,00",
    description:
      "Especialista em instalações elétricas residenciais. Materiais inclusos no preço. Garantia estendida de 1 ano.",
    deliveryTime: "04/03 às 14h",
    location: "2.1 km de você",
    warranty: "1 ano",
    status: "pending",
  },
  {
    id: 4,
    requestTitle: "Limpeza Pós-Obra",
    professional: {
      name: "Maria Oliveira",
      photo: "https://images.unsplash.com/photo-1581578949510-fa7315c4c350?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3VzZSUyMGNsZWFuaW5nJTIwc2VydmljZXxlbnwxfHx8fDE3NzI0MzQzNzB8MA&ixlib=rb-4.1.0&q=80&w=1080",
      rating: 4.9,
      reviews: 156,
      completedJobs: 198,
      verified: true,
    },
    price: "R$ 280,00",
    description:
      "Equipe especializada em limpeza pós-obra. Levamos todos os produtos necessários. Resultado impecável garantido.",
    deliveryTime: "05/03 às 9h",
    location: "4.5 km de você",
    warranty: "Satisfação garantida",
    status: "accepted",
  },
];

export function Orcamentos() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-orange-500 to-orange-600 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold mb-2">Orçamentos Recebidos</h1>
          <p className="text-orange-100">
            Compare e escolha o melhor profissional para o seu serviço
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Info Banner */}
        <div className="bg-blue-50 border-l-4 border-blue-600 p-4 mb-6 rounded-r-lg">
          <div className="flex items-start gap-3">
            <div className="bg-blue-600 text-white rounded-full p-2">
              <MessageSquare size={20} />
            </div>
            <div>
              <h3 className="font-semibold text-blue-900 mb-1">
                💡 Dica: Compare os orçamentos com atenção
              </h3>
              <p className="text-blue-800 text-sm">
                Analise não apenas o preço, mas também a avaliação, experiência e
                garantia oferecida por cada profissional.
              </p>
            </div>
          </div>
        </div>

        {/* Summary */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <Card className="p-4 bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-1">8</div>
              <div className="text-sm text-gray-700">Total de Orçamentos</div>
            </div>
          </Card>
          <Card className="p-4 bg-gradient-to-br from-green-50 to-green-100 border-2 border-green-200">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600 mb-1">1</div>
              <div className="text-sm text-gray-700">Aceito</div>
            </div>
          </Card>
          <Card className="p-4 bg-gradient-to-br from-orange-50 to-orange-100 border-2 border-orange-200">
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-600 mb-1">
                R$ 180
              </div>
              <div className="text-sm text-gray-700">Média de Preços</div>
            </div>
          </Card>
        </div>

        {/* Proposals List */}
        <div className="space-y-6">
          {proposals.map((proposal) => (
            <Card
              key={proposal.id}
              className={`p-6 hover:shadow-xl transition-all ${
                proposal.status === "accepted"
                  ? "border-2 border-green-500 bg-green-50/30"
                  : "border-2 border-transparent hover:border-blue-400"
              }`}
            >
              {proposal.status === "accepted" && (
                <div className="bg-green-500 text-white px-4 py-2 rounded-lg mb-4 flex items-center gap-2">
                  <CheckCircle size={20} />
                  <span className="font-semibold">Orçamento Aceito</span>
                </div>
              )}

              <div className="flex flex-col lg:flex-row gap-6">
                {/* Professional Info */}
                <div className="flex-1">
                  <div className="flex items-start gap-4 mb-4">
                    <div className="relative">
                      <div className="w-16 h-16 rounded-full overflow-hidden bg-gray-200">
                        <ImageWithFallback
                          src={proposal.professional.photo}
                          alt={proposal.professional.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      {proposal.professional.verified && (
                        <div className="absolute -bottom-1 -right-1 bg-blue-600 text-white rounded-full p-1">
                          <CheckCircle size={16} />
                        </div>
                      )}
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="text-xl font-bold">
                          {proposal.professional.name}
                        </h3>
                        {proposal.professional.verified && (
                          <Badge className="bg-blue-600">Verificado</Badge>
                        )}
                      </div>

                      <div className="flex items-center gap-4 text-sm text-gray-600 mb-2">
                        <div className="flex items-center gap-1">
                          <Star className="text-yellow-500 fill-yellow-500" size={16} />
                          <span className="font-semibold">
                            {proposal.professional.rating}
                          </span>
                          <span>({proposal.professional.reviews} avaliações)</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Award size={16} />
                          <span>{proposal.professional.completedJobs} serviços</span>
                        </div>
                      </div>

                      <p className="text-gray-700 mb-3">{proposal.description}</p>

                      <div className="flex flex-wrap gap-3 text-sm">
                        <div className="flex items-center gap-1 text-gray-600">
                          <Clock size={16} />
                          <span>{proposal.deliveryTime}</span>
                        </div>
                        <div className="flex items-center gap-1 text-gray-600">
                          <MapPin size={16} />
                          <span>{proposal.location}</span>
                        </div>
                        <div className="bg-green-100 text-green-800 px-3 py-1 rounded-full font-medium">
                          ✓ Garantia: {proposal.warranty}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Price and Actions */}
                <div className="lg:w-64 flex flex-col gap-3">
                  <div className="bg-gradient-to-br from-orange-50 to-orange-100 p-6 rounded-xl border-2 border-orange-300 text-center">
                    <div className="text-sm text-gray-600 mb-1">Valor Total</div>
                    <div className="text-3xl font-bold text-orange-600">
                      {proposal.price}
                    </div>
                  </div>

                  {proposal.status === "pending" ? (
                    <>
                      <Button className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800">
                        <CheckCircle className="mr-2" size={18} />
                        Aceitar Orçamento
                      </Button>
                      <Button variant="outline" className="w-full">
                        <MessageSquare className="mr-2" size={18} />
                        Enviar Mensagem
                      </Button>
                    </>
                  ) : (
                    <Button
                      variant="outline"
                      className="w-full border-green-500 text-green-700"
                      disabled
                    >
                      <CheckCircle className="mr-2" size={18} />
                      Selecionado
                    </Button>
                  )}

                  <Button variant="ghost" className="w-full text-blue-600">
                    Ver Perfil Completo
                  </Button>
                </div>
              </div>

              {/* Request Info */}
              <div className="mt-4 pt-4 border-t border-gray-200">
                <p className="text-sm text-gray-600">
                  Orçamento para: <span className="font-semibold">{proposal.requestTitle}</span>
                </p>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
