import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Textarea } from "../components/ui/textarea";
import { Label } from "../components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import { useState } from "react";
import { CheckCircle } from "lucide-react";

const categories = [
  "Reparos e Reformas",
  "Limpeza",
  "Eletricista",
  "Encanador",
  "Personal Trainer",
  "Pintura",
  "Mudanças",
  "Estética e Beleza",
  "Aulas Particulares",
  "Fotografia",
  "Jardinagem",
  "TI e Tecnologia",
];

const states = [
  "AC",
  "AL",
  "AP",
  "AM",
  "BA",
  "CE",
  "DF",
  "ES",
  "GO",
  "MA",
  "MT",
  "MS",
  "MG",
  "PA",
  "PB",
  "PR",
  "PE",
  "PI",
  "RJ",
  "RN",
  "RS",
  "RO",
  "RR",
  "SC",
  "SP",
  "SE",
  "TO",
];

export function RequestService() {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    category: "",
    title: "",
    description: "",
    name: "",
    email: "",
    phone: "",
    cep: "",
    city: "",
    state: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    setSubmitted(true);
  };

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  if (submitted) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center px-4">
        <div className="max-w-md w-full text-center">
          <div className="bg-green-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="text-green-600" size={48} />
          </div>
          <h1 className="text-3xl mb-4">Solicitação Enviada!</h1>
          <p className="text-gray-600 mb-8">
            Sua solicitação foi recebida com sucesso. Em breve, profissionais
            qualificados entrarão em contato com orçamentos personalizados.
          </p>
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
            <h3 className="font-semibold mb-2">Próximos Passos:</h3>
            <ul className="text-left space-y-2 text-sm text-gray-700">
              <li>✓ Aguarde contato dos profissionais (até 24h)</li>
              <li>✓ Compare os orçamentos recebidos</li>
              <li>✓ Escolha o profissional ideal</li>
              <li>✓ Agende o serviço</li>
            </ul>
          </div>
          <Button
            onClick={() => setSubmitted(false)}
            className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
          >
            Fazer Nova Solicitação
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="py-12">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-block mb-4">
            <span className="bg-gradient-to-r from-orange-500 to-orange-600 text-white px-4 py-2 rounded-full text-sm font-semibold uppercase tracking-wide shadow-lg">
              ⚡ Resposta Rápida Garantida
            </span>
          </div>
          <h1 className="text-4xl md:text-5xl mb-4 font-bold bg-gradient-to-r from-blue-600 to-orange-500 bg-clip-text text-transparent">Solicitar Serviço</h1>
          <p className="text-gray-600 text-lg">
            Preencha o formulário e receba <span className="text-orange-600 font-bold">até 5 orçamentos</span> de profissionais qualificados
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6 bg-white p-8 rounded-lg shadow-lg">
          {/* Category */}
          <div className="space-y-2">
            <Label htmlFor="category">Categoria do Serviço *</Label>
            <Select
              value={formData.category}
              onValueChange={(value) => handleChange("category", value)}
            >
              <SelectTrigger id="category">
                <SelectValue placeholder="Selecione uma categoria" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => (
                  <SelectItem key={cat} value={cat}>
                    {cat}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Title */}
          <div className="space-y-2">
            <Label htmlFor="title">Título do Serviço *</Label>
            <Input
              id="title"
              type="text"
              placeholder="Ex: Instalação de chuveiro elétrico"
              value={formData.title}
              onChange={(e) => handleChange("title", e.target.value)}
              required
            />
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description">Descrição Detalhada *</Label>
            <Textarea
              id="description"
              placeholder="Descreva o que você precisa, quando precisa e qualquer detalhe importante..."
              value={formData.description}
              onChange={(e) => handleChange("description", e.target.value)}
              rows={6}
              required
            />
            <p className="text-sm text-gray-500">
              Quanto mais detalhes você fornecer, melhores serão os orçamentos
            </p>
          </div>

          {/* Divider */}
          <div className="border-t pt-6">
            <h3 className="text-xl mb-4">Seus Dados de Contato</h3>
          </div>

          {/* Name */}
          <div className="space-y-2">
            <Label htmlFor="name">Nome Completo *</Label>
            <Input
              id="name"
              type="text"
              placeholder="Seu nome completo"
              value={formData.name}
              onChange={(e) => handleChange("name", e.target.value)}
              required
            />
          </div>

          {/* Email and Phone */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="email">E-mail *</Label>
              <Input
                id="email"
                type="email"
                placeholder="seu@email.com"
                value={formData.email}
                onChange={(e) => handleChange("email", e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Telefone *</Label>
              <Input
                id="phone"
                type="tel"
                placeholder="(11) 98765-4321"
                value={formData.phone}
                onChange={(e) => handleChange("phone", e.target.value)}
                required
              />
            </div>
          </div>

          {/* Location */}
          <div className="grid md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="cep">CEP *</Label>
              <Input
                id="cep"
                type="text"
                placeholder="00000-000"
                value={formData.cep}
                onChange={(e) => handleChange("cep", e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="city">Cidade *</Label>
              <Input
                id="city"
                type="text"
                placeholder="Sua cidade"
                value={formData.city}
                onChange={(e) => handleChange("city", e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="state">Estado *</Label>
              <Select
                value={formData.state}
                onValueChange={(value) => handleChange("state", value)}
              >
                <SelectTrigger id="state">
                  <SelectValue placeholder="UF" />
                </SelectTrigger>
                <SelectContent>
                  {states.map((state) => (
                    <SelectItem key={state} value={state}>
                      {state}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Submit */}
          <div className="pt-4">
            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-lg py-6 shadow-md"
            >
              Enviar Solicitação
            </Button>
            <p className="text-center text-sm text-gray-500 mt-4">
              Ao enviar, você concorda com nossos Termos de Uso e Política de
              Privacidade
            </p>
          </div>
        </form>

        {/* Additional Info */}
        <div className="mt-8 grid md:grid-cols-3 gap-4 text-center">
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="text-2xl mb-2">📝</div>
            <h4 className="font-semibold mb-1">Grátis</h4>
            <p className="text-sm text-gray-600">
              Sem custo para solicitar orçamentos
            </p>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="text-2xl mb-2">⚡</div>
            <h4 className="font-semibold mb-1">Rápido</h4>
            <p className="text-sm text-gray-600">
              Respostas em até 24 horas
            </p>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="text-2xl mb-2">🛡️</div>
            <h4 className="font-semibold mb-1">Seguro</h4>
            <p className="text-sm text-gray-600">
              Profissionais verificados
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}