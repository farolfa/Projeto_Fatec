import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Textarea } from "../components/ui/textarea";
import { Star, ThumbsUp, Award, TrendingUp } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { useState } from "react";

const pendingReviews = [
  {
    id: 1,
    service: "Pintura de Sala e Cozinha",
    professional: {
      name: "Roberto Santos",
      photo: "https://images.unsplash.com/photo-1672748341520-6a839e6c05bb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25zdHJ1Y3Rpb24lMjB3b3JrZXIlMjBzbWlsaW5nfGVufDF8fHx8MTc3MjQzNjY0OHww&ixlib=rb-4.1.0&q=80&w=1080",
    },
    completedDate: "28/02/2026",
    price: "R$ 950,00",
  },
];

const givenReviews = [
  {
    id: 1,
    service: "Instalação de Chuveiro Elétrico",
    professional: {
      name: "Carlos Silva",
      photo: "https://images.unsplash.com/photo-1556745753-b2904692b3cd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBzZXJ2aWNlJTIwd29ya2VyJTIwaGFwcHl8ZW58MXx8fHwxNzcyNDk4MTE4fDA&ixlib=rb-4.1.0&q=80&w=1080",
    },
    rating: 5,
    comment:
      "Excelente profissional! Muito pontual, educado e caprichoso no trabalho. Super recomendo!",
    date: "01/03/2026",
  },
  {
    id: 2,
    service: "Limpeza Pós-Obra",
    professional: {
      name: "Maria Oliveira",
      photo: "https://images.unsplash.com/photo-1581578949510-fa7315c4c350?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3VzZSUyMGNsZWFuaW5nJTIwc2VydmljZXxlbnwxfHx8fDE3NzI0MzQzNzB8MA&ixlib=rb-4.1.0&q=80&w=1080",
    },
    rating: 5,
    comment:
      "Equipe maravilhosa! Deixaram o apartamento impecável. Trabalho de alta qualidade.",
    date: "25/02/2026",
  },
];

export function Avaliacoes() {
  const [reviewingId, setReviewingId] = useState<number | null>(null);
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");

  const handleSubmitReview = () => {
    // Handle review submission
    setReviewingId(null);
    setRating(0);
    setComment("");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-orange-500 via-orange-600 to-orange-700 text-white py-8 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMTZ2NC4wMUgyMHYtNGgxNnptMCA4djQuMDFIMjB2LTRoMTZ6bTAgOHY0LjAxSDIwdi00aDE2eiIvPjwvZz48L2c+PC9zdmc+')] opacity-30"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="flex items-center gap-4">
            <Star size={40} className="fill-white" />
            <div>
              <h1 className="text-3xl font-bold mb-1">Avaliações</h1>
              <p className="text-orange-100">
                Avalie os serviços realizados e ajude outros usuários
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="p-6 bg-gradient-to-br from-orange-50 to-orange-100 border-2 border-orange-200">
            <div className="flex items-center gap-4">
              <div className="bg-orange-500 text-white w-12 h-12 rounded-full flex items-center justify-center">
                <Star size={24} className="fill-white" />
              </div>
              <div>
                <div className="text-3xl font-bold text-orange-600">
                  {pendingReviews.length}
                </div>
                <div className="text-sm text-gray-700">Aguardando Avaliação</div>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200">
            <div className="flex items-center gap-4">
              <div className="bg-blue-500 text-white w-12 h-12 rounded-full flex items-center justify-center">
                <ThumbsUp size={24} />
              </div>
              <div>
                <div className="text-3xl font-bold text-blue-600">
                  {givenReviews.length}
                </div>
                <div className="text-sm text-gray-700">Avaliações Feitas</div>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-green-50 to-green-100 border-2 border-green-200">
            <div className="flex items-center gap-4">
              <div className="bg-green-500 text-white w-12 h-12 rounded-full flex items-center justify-center">
                <TrendingUp size={24} />
              </div>
              <div>
                <div className="text-3xl font-bold text-green-600">100%</div>
                <div className="text-sm text-gray-700">Taxa de Satisfação</div>
              </div>
            </div>
          </Card>
        </div>

        {/* Pending Reviews */}
        {pendingReviews.length > 0 && (
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-4">
              <Award className="text-orange-600" size={24} />
              <h2 className="text-2xl font-bold">Aguardando sua Avaliação</h2>
            </div>

            <div className="space-y-4">
              {pendingReviews.map((review) => (
                <Card
                  key={review.id}
                  className="p-6 border-2 border-orange-200 bg-orange-50/30"
                >
                  <div className="flex items-start gap-4 mb-4">
                    <div className="w-16 h-16 rounded-full overflow-hidden bg-gray-200">
                      <ImageWithFallback
                        src={review.professional.photo}
                        alt={review.professional.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold mb-1">
                        {review.service}
                      </h3>
                      <p className="text-gray-600 mb-1">
                        Profissional: {review.professional.name}
                      </p>
                      <p className="text-sm text-gray-500">
                        Concluído em {review.completedDate} • {review.price}
                      </p>
                    </div>
                  </div>

                  {reviewingId === review.id ? (
                    <div className="space-y-4 bg-white p-4 rounded-lg">
                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Como foi sua experiência?
                        </label>
                        <div className="flex gap-2">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <button
                              key={star}
                              onClick={() => setRating(star)}
                              className="transition-transform hover:scale-110"
                            >
                              <Star
                                size={40}
                                className={
                                  star <= rating
                                    ? "fill-yellow-400 text-yellow-400"
                                    : "text-gray-300"
                                }
                              />
                            </button>
                          ))}
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Conte como foi (opcional)
                        </label>
                        <Textarea
                          value={comment}
                          onChange={(e) => setComment(e.target.value)}
                          placeholder="Compartilhe sua experiência com outros usuários..."
                          rows={4}
                        />
                      </div>

                      <div className="flex gap-3">
                        <Button
                          onClick={handleSubmitReview}
                          disabled={rating === 0}
                          className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700"
                        >
                          Enviar Avaliação
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => {
                            setReviewingId(null);
                            setRating(0);
                            setComment("");
                          }}
                        >
                          Cancelar
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <Button
                      onClick={() => setReviewingId(review.id)}
                      className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700"
                    >
                      <Star className="mr-2" size={18} />
                      Avaliar Agora
                    </Button>
                  )}
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Given Reviews */}
        <div>
          <h2 className="text-2xl font-bold mb-4">Suas Avaliações</h2>

          <div className="space-y-4">
            {givenReviews.map((review) => (
              <Card key={review.id} className="p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-start gap-4">
                  <div className="w-16 h-16 rounded-full overflow-hidden bg-gray-200">
                    <ImageWithFallback
                      src={review.professional.photo}
                      alt={review.professional.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="text-lg font-bold mb-1">
                          {review.service}
                        </h3>
                        <p className="text-gray-600 text-sm">
                          {review.professional.name}
                        </p>
                      </div>
                      <div className="flex items-center gap-1">
                        {[...Array(review.rating)].map((_, i) => (
                          <Star
                            key={i}
                            size={20}
                            className="fill-yellow-400 text-yellow-400"
                          />
                        ))}
                      </div>
                    </div>

                    <p className="text-gray-700 mb-3 italic">
                      "{review.comment}"
                    </p>

                    <div className="flex items-center justify-between">
                      <p className="text-sm text-gray-500">
                        Avaliado em {review.date}
                      </p>
                      <Badge className="bg-green-100 text-green-800 border-green-300">
                        ✓ Publicada
                      </Badge>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          {givenReviews.length === 0 && (
            <Card className="p-12 text-center">
              <Star className="mx-auto text-gray-400 mb-4" size={64} />
              <h3 className="text-xl font-semibold mb-2">
                Nenhuma avaliação ainda
              </h3>
              <p className="text-gray-600">
                Suas avaliações aparecerão aqui após você avaliar os serviços
              </p>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
