import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import { Avatar } from "../components/ui/avatar";
import {
  MessageSquare,
  Send,
  Search,
  MoreVertical,
  Paperclip,
  Smile,
} from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { useState } from "react";

const conversations = [
  {
    id: 1,
    professional: {
      name: "Carlos Silva",
      photo: "https://images.unsplash.com/photo-1556745753-b2904692b3cd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBzZXJ2aWNlJTIwd29ya2VyJTIwaGFwcHl8ZW58MXx8fHwxNzcyNDk4MTE4fDA&ixlib=rb-4.1.0&q=80&w=1080",
      online: true,
    },
    lastMessage: "Posso fazer o serviço amanhã às 14h",
    time: "Há 5 min",
    unread: 2,
    service: "Instalação de Chuveiro",
  },
  {
    id: 2,
    professional: {
      name: "Maria Oliveira",
      photo: "https://images.unsplash.com/photo-1581578949510-fa7315c4c350?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3VzZSUyMGNsZWFuaW5nJTIwc2VydmljZXxlbnwxfHx8fDE3NzI0MzQzNzB8MA&ixlib=rb-4.1.0&q=80&w=1080",
      online: true,
    },
    lastMessage: "Olá! Quando seria o melhor horário?",
    time: "Há 1 hora",
    unread: 1,
    service: "Limpeza Pós-Obra",
  },
  {
    id: 3,
    professional: {
      name: "Roberto Santos",
      photo: "https://images.unsplash.com/photo-1672748341520-6a839e6c05bb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25zdHJ1Y3Rpb24lMjB3b3JrZXIlMjBzbWlsaW5nfGVufDF8fHx8MTc3MjQzNjY0OHww&ixlib=rb-4.1.0&q=80&w=1080",
      online: false,
    },
    lastMessage: "Muito obrigado pela oportunidade!",
    time: "Ontem",
    unread: 0,
    service: "Pintura",
  },
];

const currentChat = [
  {
    id: 1,
    sender: "them",
    message: "Boa tarde! Vi seu pedido de instalação de chuveiro elétrico.",
    time: "14:32",
  },
  {
    id: 2,
    sender: "them",
    message: "Posso fazer o serviço com garantia de 90 dias por R$ 180.",
    time: "14:33",
  },
  {
    id: 3,
    sender: "me",
    message: "Olá! Qual seria a disponibilidade?",
    time: "14:35",
  },
  {
    id: 4,
    sender: "them",
    message: "Posso fazer amanhã pela manhã ou na quinta-feira à tarde.",
    time: "14:36",
  },
  {
    id: 5,
    sender: "me",
    message: "Perfeito! Amanhã pela manhã está ótimo.",
    time: "14:38",
  },
  {
    id: 6,
    sender: "them",
    message: "Posso fazer o serviço amanhã às 14h",
    time: "14:40",
  },
];

export function Mensagens() {
  const [selectedConversation, setSelectedConversation] = useState(conversations[0]);
  const [messageText, setMessageText] = useState("");

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-4">
            <MessageSquare size={40} />
            <div>
              <h1 className="text-3xl font-bold mb-1">Mensagens</h1>
              <p className="text-blue-100">
                Converse com os profissionais sobre seus serviços
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-3 gap-6 h-[calc(100vh-280px)]">
          {/* Conversations List */}
          <div className="lg:col-span-1">
            <Card className="h-full flex flex-col">
              {/* Search */}
              <div className="p-4 border-b">
                <div className="relative">
                  <Search
                    className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                    size={18}
                  />
                  <Input
                    type="text"
                    placeholder="Buscar conversas..."
                    className="pl-10"
                  />
                </div>
              </div>

              {/* Conversations */}
              <div className="flex-1 overflow-y-auto">
                {conversations.map((conv) => (
                  <div
                    key={conv.id}
                    onClick={() => setSelectedConversation(conv)}
                    className={`p-4 border-b cursor-pointer hover:bg-gray-50 transition-colors ${
                      selectedConversation.id === conv.id ? "bg-blue-50" : ""
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      {/* Avatar */}
                      <div className="relative flex-shrink-0">
                        <div className="w-12 h-12 rounded-full overflow-hidden bg-gray-200">
                          <ImageWithFallback
                            src={conv.professional.photo}
                            alt={conv.professional.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        {conv.professional.online && (
                          <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>
                        )}
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="font-semibold text-sm truncate">
                            {conv.professional.name}
                          </h4>
                          <span className="text-xs text-gray-500 flex-shrink-0 ml-2">
                            {conv.time}
                          </span>
                        </div>
                        <p className="text-xs text-gray-600 mb-1 truncate">
                          {conv.service}
                        </p>
                        <div className="flex items-center justify-between">
                          <p className="text-sm text-gray-600 truncate">
                            {conv.lastMessage}
                          </p>
                          {conv.unread > 0 && (
                            <Badge className="ml-2 bg-orange-500 text-white text-xs px-2">
                              {conv.unread}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Chat Area */}
          <div className="lg:col-span-2">
            <Card className="h-full flex flex-col">
              {/* Chat Header */}
              <div className="p-4 border-b bg-gradient-to-r from-blue-50 to-orange-50">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <div className="w-12 h-12 rounded-full overflow-hidden bg-gray-200">
                        <ImageWithFallback
                          src={selectedConversation.professional.photo}
                          alt={selectedConversation.professional.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      {selectedConversation.professional.online && (
                        <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>
                      )}
                    </div>
                    <div>
                      <h3 className="font-bold">
                        {selectedConversation.professional.name}
                      </h3>
                      <p className="text-sm text-gray-600">
                        {selectedConversation.professional.online
                          ? "Online agora"
                          : "Offline"}
                      </p>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm">
                    <MoreVertical size={20} />
                  </Button>
                </div>
                <div className="mt-2">
                  <Badge variant="outline" className="text-xs">
                    {selectedConversation.service}
                  </Badge>
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
                {currentChat.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex ${
                      msg.sender === "me" ? "justify-end" : "justify-start"
                    }`}
                  >
                    <div
                      className={`max-w-[70%] rounded-2xl px-4 py-3 ${
                        msg.sender === "me"
                          ? "bg-gradient-to-r from-blue-600 to-blue-700 text-white"
                          : "bg-white border border-gray-200"
                      }`}
                    >
                      <p className="text-sm">{msg.message}</p>
                      <p
                        className={`text-xs mt-1 ${
                          msg.sender === "me" ? "text-blue-100" : "text-gray-500"
                        }`}
                      >
                        {msg.time}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Message Input */}
              <div className="p-4 border-t bg-white">
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="sm" className="flex-shrink-0">
                    <Paperclip size={20} />
                  </Button>
                  <Input
                    type="text"
                    placeholder="Digite sua mensagem..."
                    value={messageText}
                    onChange={(e) => setMessageText(e.target.value)}
                    className="flex-1"
                    onKeyPress={(e) => {
                      if (e.key === "Enter" && messageText.trim()) {
                        // Handle send message
                        setMessageText("");
                      }
                    }}
                  />
                  <Button variant="ghost" size="sm" className="flex-shrink-0">
                    <Smile size={20} />
                  </Button>
                  <Button
                    className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 flex-shrink-0"
                    disabled={!messageText.trim()}
                  >
                    <Send size={18} />
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
