import { Link } from "react-router";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Input } from "../components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import { Search, Filter, Calendar, MapPin, DollarSign } from "lucide-react";
import { useState } from "react";

const allRequests = [
  {
    id: 1,
    title: "Instalação de Chuveiro Elétrico",
    category: "Eletricista",
    status: "pending",
    description: "Preciso instalar um chuveiro elétrico de 220V no banheiro",
    location: "São Paulo, SP",
    date: "03/03/2026",
    proposals: 3,
    budget: "R$ 150 - R$ 300",
  },
  {
    id: 2,
    title: "Limpeza Pós-Obra",
    category: "Limpeza",
    status: "active",
    description: "Limpeza completa de apartamento após reforma",
    location: "São Paulo, SP",
    date: "02/03/2026",
    proposals: 5,
    budget: "R$ 200 - R$ 400",
  },
  {
    id: 3,
    title: "Pintura de Sala e Cozinha",
    category: "Pintura",
    status: "completed",
    description: "Pintura de dois cômodos, aproximadamente 40m²",
    location: "São Paulo, SP",
    date: "28/02/2026",
    proposals: 4,
    budget: "R$ 800 - R$ 1.200",
  },
  {
    id: 4,
    title: "Conserto de Vazamento",
    category: "Encanador",
    status: "active",
    description: "Vazamento na tubulação da pia da cozinha",
    location: "São Paulo, SP",
    date: "01/03/2026",
    proposals: 6,
    budget: "R$ 100 - R$ 250",
  },
  {
    id: 5,
    title: "Montagem de Móveis",
    category: "Reparos e Reformas",
    status: "completed",
    description: "Montagem de guarda-roupa de 6 portas e cômoda",
    location: "São Paulo, SP",
    date: "25/02/2026",
    proposals: 4,
    budget: "R$ 150 - R$ 300",
  },
];

export function MeusPedidos() {
  const [filterStatus, setFilterStatus] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const getStatusBadge = (status: string) => {
    const badges = {
      pending: {
        label: "Aguardando Orçamentos",
        className: "bg-yellow-100 text-yellow-800 border-yellow-300",
      },
      active: {
        label: "Orçamentos Recebidos",
        className: "bg-blue-100 text-blue-800 border-blue-300",
      },
      completed: {
        label: "Concluído",
        className: "bg-green-100 text-green-800 border-green-300",
      },
    };
    return badges[status as keyof typeof badges] || badges.pending;
  };

  const filteredRequests = allRequests.filter((request) => {
    const matchesStatus = filterStatus === "all" || request.status === filterStatus;
    const matchesSearch =
      request.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      request.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold mb-2">Meus Pedidos</h1>
          <p className="text-blue-100">Gerencie todos os seus pedidos de serviço</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Actions Bar */}
        <div className="bg-white rounded-lg shadow-md p-4 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                size={20}
              />
              <Input
                type="text"
                placeholder="Buscar pedidos..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Filter by Status */}
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-full md:w-48">
                <Filter size={16} className="mr-2" />
                <SelectValue placeholder="Filtrar por status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="pending">Aguardando</SelectItem>
                <SelectItem value="active">Com Orçamentos</SelectItem>
                <SelectItem value="completed">Concluídos</SelectItem>
              </SelectContent>
            </Select>

            {/* New Request Button */}
            <Link to="/solicitar-servico">
              <Button className="w-full md:w-auto bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700">
                + Novo Pedido
              </Button>
            </Link>
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-4">
          <p className="text-gray-600">
            <span className="font-semibold">{filteredRequests.length}</span> pedido
            {filteredRequests.length !== 1 ? "s" : ""} encontrado
            {filteredRequests.length !== 1 ? "s" : ""}
          </p>
        </div>

        {/* Requests List */}
        <div className="space-y-4">
          {filteredRequests.map((request) => {
            const badge = getStatusBadge(request.status);
            return (
              <Card
                key={request.id}
                className="p-6 hover:shadow-xl transition-all border-2 border-transparent hover:border-blue-400"
              >
                <div className="flex flex-col lg:flex-row gap-6">
                  {/* Main Info */}
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="text-xl font-bold mb-1">
                          {request.title}
                        </h3>
                        <p className="text-gray-600 text-sm">
                          {request.category}
                        </p>
                      </div>
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-semibold border ${badge.className}`}
                      >
                        {badge.label}
                      </span>
                    </div>

                    <p className="text-gray-700 mb-4">{request.description}</p>

                    <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                      <div className="flex items-center gap-1">
                        <Calendar size={16} />
                        <span>{request.date}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <MapPin size={16} />
                        <span>{request.location}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <DollarSign size={16} />
                        <span>{request.budget}</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="lg:w-48 flex flex-col gap-3">
                    <div className="bg-gradient-to-r from-blue-50 to-orange-50 p-4 rounded-lg text-center border-2 border-blue-200">
                      <div className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-orange-500 bg-clip-text text-transparent">
                        {request.proposals}
                      </div>
                      <div className="text-sm text-gray-600">
                        Orçamento{request.proposals !== 1 ? "s" : ""}
                      </div>
                    </div>

                    <Link to={`/dashboard/pedido/${request.id}`}>
                      <Button className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800">
                        Ver Detalhes
                      </Button>
                    </Link>

                    {request.status === "active" && (
                      <Link to={`/dashboard/orcamentos?pedido=${request.id}`}>
                        <Button variant="outline" className="w-full">
                          Ver Orçamentos
                        </Button>
                      </Link>
                    )}
                  </div>
                </div>
              </Card>
            );
          })}
        </div>

        {/* Empty State */}
        {filteredRequests.length === 0 && (
          <Card className="p-12 text-center">
            <div className="text-gray-400 mb-4">
              <Search size={64} className="mx-auto" />
            </div>
            <h3 className="text-xl font-semibold mb-2">
              Nenhum pedido encontrado
            </h3>
            <p className="text-gray-600 mb-6">
              Tente ajustar os filtros ou faça um novo pedido
            </p>
            <Link to="/solicitar-servico">
              <Button className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700">
                + Solicitar Serviço
              </Button>
            </Link>
          </Card>
        )}
      </div>
    </div>
  );
}
