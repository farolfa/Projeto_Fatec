import { Button } from "../../components/ui/button";
import { Card } from "../../components/ui/card";
import { Badge } from "../../components/ui/badge";
import { Input } from "../../components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../../components/ui/select";
import {
  Search,
  MapPin,
  Calendar,
  DollarSign,
  Send,
  Filter,
  TrendingUp,
} from "lucide-react";
import { useState } from "react";

const availableServices = [
  {
    id: 1,
    title: "Instalação de Chuveiro Elétrico",
    category: "Eletricista",
    client: "João Silva",
    description: "Preciso instalar um chuveiro elétrico de 220V no banheiro. Já tenho o chuveiro.",
    location: "Jardim Paulista, São Paulo - SP",
    distance: "3.2 km",
    date: "03/03/2026",
    budget: "R$ 150 - R$ 300",
    urgency: "high",
    proposals: 3,
  },
  {
    id: 2,
    title: "Conserto de Vazamento em Pia",
    category: "Encanador",
    client: "Maria Santos",
    description: "Vazamento embaixo da pia da cozinha. Preciso de urgência.",
    location: "Vila Mariana, São Paulo - SP",
    distance: "5.8 km",
    date: "03/03/2026",
    budget: "R$ 100 - R$ 250",
    urgency: "urgent",
    proposals: 6,
  },
  {
    id: 3,
    title: "Pintura de Quarto",
    category: "Pintura",
    client: "Carlos Oliveira",
    description: "Pintura de um quarto de aproximadamente 12m². Cliente fornece a tinta.",
    location: "Moema, São Paulo - SP",
    distance: "7.5 km",
    date: "04/03/2026",
    budget: "R$ 300 - R$ 500",
    urgency: "normal",
    proposals: 8,
  },
  {
    id: 4,
    title: "Limpeza Pós-Reforma",
    category: "Limpeza",
    client: "Ana Paula",
    description: "Apartamento de 70m² precisa de limpeza completa após reforma.",
    location: "Pinheiros, São Paulo - SP",
    distance: "4.1 km",
    date: "05/03/2026",
    budget: "R$ 200 - R$ 400",
    urgency: "normal",
    proposals: 5,
  },
  {
    id: 5,
    title: "Instalação de Ventilador de Teto",
    category: "Eletricista",
    client: "Roberto Lima",
    description: "Instalar 2 ventiladores de teto nos quartos.",
    location: "Itaim Bibi, São Paulo - SP",
    distance: "2.3 km",
    date: "03/03/2026",
    budget: "R$ 200 - R$ 350",
    urgency: "high",
    proposals: 4,
  },
];

export function ServicosDisponiveis() {
  const [filterCategory, setFilterCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const getUrgencyBadge = (urgency: string) => {
    const badges = {
      urgent: {
        label: "🔴 URGENTE",
        className: "bg-red-100 text-red-800 border-red-300",
      },
      high: {
        label: "🟡 Alta Prioridade",
        className: "bg-yellow-100 text-yellow-800 border-yellow-300",
      },
      normal: {
        label: "🟢 Normal",
        className: "bg-green-100 text-green-800 border-green-300",
      },
    };
    return badges[urgency as keyof typeof badges] || badges.normal;
  };

  const filteredServices = availableServices.filter((service) => {
    const matchesCategory = filterCategory === "all" || service.category === filterCategory;
    const matchesSearch =
      service.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      service.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-orange-500 via-orange-600 to-blue-600 text-white py-8 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDE2djQuMDFIMjB2LTRoMTZ6bTAgOHY0LjAxSDIwdi00aDE2em0wIDh2NC4wMUgyMHYtNGgxNnoiLz48L2c+PC9nPjwvc3ZnPg==')] opacity-30"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <TrendingUp size={40} />
              <div>
                <h1 className="text-3xl font-bold mb-1">Serviços Disponíveis</h1>
                <p className="text-orange-100">
                  <span className="font-bold text-white">{filteredServices.length}</span> oportunidades aguardando você!
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Info Banner */}
        <div className="bg-gradient-to-r from-orange-50 to-blue-50 border-l-4 border-orange-600 p-4 mb-6 rounded-r-lg">
          <div className="flex items-start gap-3">
            <div className="bg-orange-600 text-white rounded-full p-2">
              <TrendingUp size={20} />
            </div>
            <div>
              <h3 className="font-semibold text-orange-900 mb-1">
                💰 Dica: Aumente suas chances!
              </h3>
              <p className="text-orange-800 text-sm">
                Responda rápido e seja profissional. Clientes valorizam orçamentos detalhados e respostas rápidas.
              </p>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg shadow-md p-4 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                size={20}
              />
              <Input
                type="text"
                placeholder="Buscar serviços..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger className="w-full md:w-48">
                <Filter size={16} className="mr-2" />
                <SelectValue placeholder="Categoria" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas Categorias</SelectItem>
                <SelectItem value="Eletricista">Eletricista</SelectItem>
                <SelectItem value="Encanador">Encanador</SelectItem>
                <SelectItem value="Pintura">Pintura</SelectItem>
                <SelectItem value="Limpeza">Limpeza</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Services List */}
        <div className="space-y-4">
          {filteredServices.map((service) => {
            const urgencyBadge = getUrgencyBadge(service.urgency);
            return (
              <Card
                key={service.id}
                className="p-6 hover:shadow-xl transition-all border-l-4 border-l-orange-500"
              >
                <div className="flex flex-col lg:flex-row gap-6">
                  {/* Main Info */}
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="text-xl font-bold mb-1">{service.title}</h3>
                        <p className="text-gray-600 text-sm">{service.category}</p>
                      </div>
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-semibold border ${urgencyBadge.className}`}
                      >
                        {urgencyBadge.label}
                      </span>
                    </div>

                    <p className="text-gray-700 mb-4">{service.description}</p>

                    <div className="flex flex-wrap gap-4 text-sm text-gray-600 mb-4">
                      <div className="flex items-center gap-1">
                        <Calendar size={16} />
                        <span>Postado em {service.date}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <MapPin size={16} />
                        <span>{service.location}</span>
                      </div>
                      <div className="flex items-center gap-1 text-green-700 font-medium">
                        <span>📍 {service.distance} de você</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="bg-orange-100 text-orange-800 px-4 py-2 rounded-lg font-semibold border-2 border-orange-300">
                        <DollarSign size={16} className="inline mr-1" />
                        {service.budget}
                      </div>
                      <div className="text-sm text-gray-600">
                        {service.proposals} profissionais já enviaram propostas
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="lg:w-64 flex flex-col gap-3">
                    <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-4 rounded-lg text-center border-2 border-blue-300">
                      <div className="text-sm text-gray-600 mb-1">Cliente</div>
                      <div className="text-lg font-bold text-blue-700">
                        {service.client}
                      </div>
                    </div>

                    <Button className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 shadow-md">
                      <Send className="mr-2" size={18} />
                      Enviar Orçamento
                    </Button>

                    <Button variant="outline" className="w-full">
                      Ver Mais Detalhes
                    </Button>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>

        {/* Empty State */}
        {filteredServices.length === 0 && (
          <Card className="p-12 text-center">
            <Search className="mx-auto text-gray-400 mb-4" size={64} />
            <h3 className="text-xl font-semibold mb-2">
              Nenhum serviço encontrado
            </h3>
            <p className="text-gray-600 mb-6">
              Tente ajustar os filtros ou volte mais tarde
            </p>
          </Card>
        )}
      </div>
    </div>
  );
}