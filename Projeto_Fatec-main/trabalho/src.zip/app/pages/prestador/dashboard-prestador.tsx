import { Link } from "react-router";
import { Button } from "../../components/ui/button";
import { Card } from "../../components/ui/card";
import {
  Briefcase,
  DollarSign,
  TrendingUp,
  Star,
  Clock,
  CheckCircle,
  Send,
  Award,
} from "lucide-react";

const stats = [
  {
    label: "Propostas Enviadas",
    value: "12",
    icon: Send,
    color: "blue",
    change: "+3 esta semana",
  },
  {
    label: "Propostas Aceitas",
    value: "5",
    icon: CheckCircle,
    color: "green",
    change: "Taxa de 42%",
  },
  {
    label: "Serviços Concluídos",
    value: "28",
    icon: Briefcase,
    color: "orange",
    change: "+2 este mês",
  },
  {
    label: "Avaliação Média",
    value: "4.9",
    icon: Star,
    color: "yellow",
    change: "127 avaliações",
  },
];

const recentOpportunities = [
  {
    id: 1,
    title: "Instalação de Chuveiro Elétrico",
    category: "Eletricista",
    location: "Jardim Paulista, SP",
    distance: "3.2 km",
    budget: "R$ 150 - R$ 300",
    urgency: "high",
    posted: "Há 30 min",
  },
  {
    id: 2,
    title: "Conserto de Vazamento",
    category: "Encanador",
    location: "Vila Mariana, SP",
    distance: "5.8 km",
    budget: "R$ 100 - R$ 250",
    urgency: "urgent",
    posted: "Há 1 hora",
  },
  {
    id: 3,
    title: "Pintura de Quarto",
    category: "Pintura",
    location: "Moema, SP",
    distance: "7.5 km",
    budget: "R$ 300 - R$ 500",
    urgency: "normal",
    posted: "Há 2 horas",
  },
];

const earnings = {
  thisMonth: "R$ 3.450,00",
  lastMonth: "R$ 2.890,00",
  average: "R$ 345,00",
  total: "R$ 28.900,00",
};

export function DashboardPrestador() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 via-blue-700 to-orange-500 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-4 mb-4">
            <Briefcase size={40} />
            <div>
              <h1 className="text-3xl font-bold">Olá, Carlos! 👋</h1>
              <p className="text-blue-100">Bem-vindo à sua área de trabalho</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Quick Action */}
        <div className="mb-8">
          <Link to="/prestador/servicos-disponiveis">
            <Button
              size="lg"
              className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 shadow-lg"
            >
              <TrendingUp className="mr-2" size={20} />
              Ver Serviços Disponíveis
            </Button>
          </Link>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index} className="p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center justify-between mb-4">
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center ${
                    stat.color === "blue"
                      ? "bg-blue-100"
                      : stat.color === "green"
                      ? "bg-green-100"
                      : stat.color === "orange"
                      ? "bg-orange-100"
                      : "bg-yellow-100"
                  }`}
                >
                  <stat.icon
                    className={
                      stat.color === "blue"
                        ? "text-blue-600"
                        : stat.color === "green"
                        ? "text-green-600"
                        : stat.color === "orange"
                        ? "text-orange-600"
                        : "text-yellow-600"
                    }
                    size={24}
                  />
                </div>
              </div>
              <p className="text-gray-600 text-sm mb-1">{stat.label}</p>
              <p className="text-3xl font-bold mb-1">{stat.value}</p>
              <p className="text-xs text-gray-500">{stat.change}</p>
            </Card>
          ))}
        </div>

        {/* Earnings Overview */}
        <Card className="p-6 mb-8 bg-gradient-to-br from-orange-50 to-orange-100 border-2 border-orange-200">
          <div className="flex items-center gap-3 mb-6">
            <div className="bg-orange-600 text-white w-12 h-12 rounded-full flex items-center justify-center">
              <DollarSign size={24} />
            </div>
            <h2 className="text-2xl font-bold">Seus Ganhos</h2>
          </div>
          <div className="grid md:grid-cols-4 gap-6">
            <div>
              <p className="text-sm text-gray-600 mb-1">Este Mês</p>
              <p className="text-2xl font-bold text-orange-600">{earnings.thisMonth}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600 mb-1">Mês Anterior</p>
              <p className="text-2xl font-bold text-gray-700">{earnings.lastMonth}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600 mb-1">Média por Serviço</p>
              <p className="text-2xl font-bold text-blue-600">{earnings.average}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600 mb-1">Total Ganho</p>
              <p className="text-2xl font-bold text-orange-600">{earnings.total}</p>
            </div>
          </div>
        </Card>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Recent Opportunities */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold">Novas Oportunidades</h2>
              <Link to="/prestador/servicos-disponiveis">
                <Button variant="outline" size="sm">
                  Ver Todas
                </Button>
              </Link>
            </div>

            <div className="space-y-3">
              {recentOpportunities.map((opp) => (
                <Card
                  key={opp.id}
                  className="p-4 hover:shadow-lg transition-all border-l-4 border-l-orange-500"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="font-bold mb-1">{opp.title}</h3>
                      <p className="text-sm text-gray-600">{opp.category}</p>
                    </div>
                    <span
                      className={`px-2 py-1 rounded-full text-xs font-semibold ${
                        opp.urgency === "urgent"
                          ? "bg-red-100 text-red-800"
                          : opp.urgency === "high"
                          ? "bg-yellow-100 text-yellow-800"
                          : "bg-green-100 text-green-800"
                      }`}
                    >
                      {opp.urgency === "urgent"
                        ? "URGENTE"
                        : opp.urgency === "high"
                        ? "ALTA"
                        : "NORMAL"}
                    </span>
                  </div>
                  <div className="text-sm text-gray-600 mb-3">
                    <p>📍 {opp.location} • {opp.distance}</p>
                    <p className="font-semibold text-orange-600">💰 {opp.budget}</p>
                  </div>
                  <div className="flex items-center justify-between">
                    <p className="text-xs text-gray-500">{opp.posted}</p>
                    <Link to="/prestador/servicos-disponiveis">
                      <Button size="sm" className="bg-orange-600 hover:bg-orange-700">
                        Enviar Orçamento
                      </Button>
                    </Link>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          {/* Performance & Tips */}
          <div>
            <h2 className="text-2xl font-bold mb-4">Seu Desempenho</h2>

            <Card className="p-6 mb-4 bg-gradient-to-br from-yellow-50 to-yellow-100 border-2 border-yellow-200">
              <div className="flex items-center gap-3 mb-4">
                <div className="bg-yellow-500 text-white w-12 h-12 rounded-full flex items-center justify-center">
                  <Award size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-lg">Profissional Destaque</h3>
                  <p className="text-sm text-gray-600">Top 10% da plataforma</p>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Taxa de resposta</span>
                  <span className="font-bold text-green-600">95%</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Tempo médio de resposta</span>
                  <span className="font-bold text-blue-600">2h</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Taxa de conclusão</span>
                  <span className="font-bold text-green-600">98%</span>
                </div>
              </div>
            </Card>

            <Card className="p-6 bg-blue-50 border-2 border-blue-200">
              <h3 className="font-bold mb-3 flex items-center gap-2">
                <TrendingUp className="text-blue-600" size={20} />
                Dicas para Ganhar Mais
              </h3>
              <ul className="space-y-2 text-sm text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="text-green-600">✓</span>
                  <span>Responda rápido às novas oportunidades</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600">✓</span>
                  <span>Mantenha seu perfil sempre atualizado</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600">✓</span>
                  <span>Capriche nos detalhes das propostas</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600">✓</span>
                  <span>Peça avaliações aos clientes satisfeitos</span>
                </li>
              </ul>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}