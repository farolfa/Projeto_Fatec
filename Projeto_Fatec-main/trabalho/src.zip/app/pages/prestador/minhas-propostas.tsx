import { Button } from "../../components/ui/button";
import { Card } from "../../components/ui/card";
import { Badge } from "../../components/ui/badge";
import { Input } from "../../components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../../components/ui/select";
import {
  Search,
  Filter,
  DollarSign,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  MessageSquare,
} from "lucide-react";
import { useState } from "react";

const myProposals = [
  {
    id: 1,
    serviceTitle: "Instalação de Chuveiro Elétrico",
    client: "João Silva",
    myPrice: "R$ 180,00",
    status: "pending",
    sentDate: "Há 2 horas",
    description: "Faço instalação com garantia de 90 dias. Trabalho com materiais de qualidade.",
    deliveryTime: "Amanhã, 04/03",
    competitors: 3,
  },
  {
    id: 2,
    serviceTitle: "Limpeza Pós-Obra",
    client: "Ana Paula",
    myPrice: "R$ 280,00",
    status: "accepted",
    sentDate: "Ontem",
    description: "Equipe especializada em limpeza pós-obra. Levamos todos os produtos necessários.",
    deliveryTime: "05/03 às 9h",
    competitors: 5,
    scheduledDate: "05/03/2026 - 9h",
  },
  {
    id: 3,
    serviceTitle: "Pintura de Sala",
    client: "Carlos Oliveira",
    myPrice: "R$ 450,00",
    status: "rejected",
    sentDate: "Há 2 dias",
    description: "Pintura profissional com acabamento impecável.",
    deliveryTime: "07/03",
    competitors: 8,
  },
  {
    id: 4,
    serviceTitle: "Conserto de Vazamento",
    client: "Maria Santos",
    myPrice: "R$ 120,00",
    status: "pending",
    sentDate: "Há 1 dia",
    description: "Atendimento rápido para vazamentos. Disponível hoje mesmo.",
    deliveryTime: "Hoje",
    competitors: 6,
  },
];

export function MinhasPropostas() {
  const [filterStatus, setFilterStatus] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const getStatusBadge = (status: string) => {
    const badges = {
      pending: {
        label: "Aguardando Cliente",
        icon: Clock,
        className: "bg-yellow-100 text-yellow-800 border-yellow-300",
      },
      accepted: {
        label: "Aceita ✓",
        icon: CheckCircle,
        className: "bg-green-100 text-green-800 border-green-300",
      },
      rejected: {
        label: "Não Selecionada",
        icon: XCircle,
        className: "bg-red-100 text-red-800 border-red-300",
      },
    };
    return badges[status as keyof typeof badges] || badges.pending;
  };

  const filteredProposals = myProposals.filter((proposal) => {
    const matchesStatus = filterStatus === "all" || proposal.status === filterStatus;
    const matchesSearch =
      proposal.serviceTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      proposal.client.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const stats = {
    total: myProposals.length,
    pending: myProposals.filter((p) => p.status === "pending").length,
    accepted: myProposals.filter((p) => p.status === "accepted").length,
    rejected: myProposals.filter((p) => p.status === "rejected").length,
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-4">
            <DollarSign size={40} />
            <div>
              <h1 className="text-3xl font-bold mb-1">Minhas Propostas</h1>
              <p className="text-blue-100">Acompanhe todas as suas propostas enviadas</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Card className="p-4 bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-1">{stats.total}</div>
              <div className="text-sm text-gray-700">Total Enviadas</div>
            </div>
          </Card>
          <Card className="p-4 bg-gradient-to-br from-yellow-50 to-yellow-100 border-2 border-yellow-200">
            <div className="text-center">
              <div className="text-3xl font-bold text-yellow-600 mb-1">{stats.pending}</div>
              <div className="text-sm text-gray-700">Aguardando</div>
            </div>
          </Card>
          <Card className="p-4 bg-gradient-to-br from-green-50 to-green-100 border-2 border-green-200">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600 mb-1">{stats.accepted}</div>
              <div className="text-sm text-gray-700">Aceitas</div>
            </div>
          </Card>
          <Card className="p-4 bg-gradient-to-br from-gray-50 to-gray-100 border-2 border-gray-200">
            <div className="text-center">
              <div className="text-3xl font-bold text-gray-600 mb-1">{stats.rejected}</div>
              <div className="text-sm text-gray-700">Não Selecionadas</div>
            </div>
          </Card>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg shadow-md p-4 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                size={20}
              />
              <Input
                type="text"
                placeholder="Buscar propostas..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-full md:w-48">
                <Filter size={16} className="mr-2" />
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="pending">Aguardando</SelectItem>
                <SelectItem value="accepted">Aceitas</SelectItem>
                <SelectItem value="rejected">Não Selecionadas</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Proposals List */}
        <div className="space-y-4">
          {filteredProposals.map((proposal) => {
            const statusBadge = getStatusBadge(proposal.status);
            const StatusIcon = statusBadge.icon;

            return (
              <Card
                key={proposal.id}
                className={`p-6 hover:shadow-xl transition-all ${
                  proposal.status === "accepted"
                    ? "border-2 border-green-500 bg-green-50/30"
                    : ""
                }`}
              >
                {proposal.status === "accepted" && (
                  <div className="bg-green-500 text-white px-4 py-2 rounded-lg mb-4 flex items-center gap-2">
                    <CheckCircle size={20} />
                    <span className="font-semibold">
                      Parabéns! Proposta aceita - Agendado para {proposal.scheduledDate}
                    </span>
                  </div>
                )}

                <div className="flex flex-col lg:flex-row gap-6">
                  {/* Main Info */}
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="text-xl font-bold mb-1">
                          {proposal.serviceTitle}
                        </h3>
                        <p className="text-gray-600 text-sm">
                          Cliente: {proposal.client}
                        </p>
                      </div>
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-semibold border flex items-center gap-1 ${statusBadge.className}`}
                      >
                        <StatusIcon size={14} />
                        {statusBadge.label}
                      </span>
                    </div>

                    <p className="text-gray-700 mb-4 italic">
                      "{proposal.description}"
                    </p>

                    <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                      <div className="flex items-center gap-1">
                        <Clock size={16} />
                        <span>Enviada {proposal.sentDate}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <AlertCircle size={16} />
                        <span>Prazo: {proposal.deliveryTime}</span>
                      </div>
                      <div className="text-orange-600 font-medium">
                        {proposal.competitors} profissionais concorrendo
                      </div>
                    </div>
                  </div>

                  {/* Price and Actions */}
                  <div className="lg:w-64 flex flex-col gap-3">
                    <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-xl border-2 border-green-300 text-center">
                      <div className="text-sm text-gray-600 mb-1">Seu Orçamento</div>
                      <div className="text-3xl font-bold text-green-600">
                        {proposal.myPrice}
                      </div>
                    </div>

                    {proposal.status === "pending" && (
                      <>
                        <Button variant="outline" className="w-full">
                          Editar Proposta
                        </Button>
                        <Button
                          variant="outline"
                          className="w-full text-blue-600 border-blue-300"
                        >
                          <MessageSquare className="mr-2" size={18} />
                          Mensagem
                        </Button>
                      </>
                    )}

                    {proposal.status === "accepted" && (
                      <Button className="w-full bg-gradient-to-r from-green-600 to-green-700">
                        <MessageSquare className="mr-2" size={18} />
                        Contatar Cliente
                      </Button>
                    )}

                    {proposal.status === "rejected" && (
                      <Button variant="outline" disabled className="w-full">
                        Cliente escolheu outro
                      </Button>
                    )}
                  </div>
                </div>
              </Card>
            );
          })}
        </div>

        {/* Empty State */}
        {filteredProposals.length === 0 && (
          <Card className="p-12 text-center">
            <DollarSign className="mx-auto text-gray-400 mb-4" size={64} />
            <h3 className="text-xl font-semibold mb-2">
              Nenhuma proposta encontrada
            </h3>
            <p className="text-gray-600">
              Você ainda não enviou propostas{" "}
              {filterStatus !== "all" ? "com este status" : ""}
            </p>
          </Card>
        )}
      </div>
    </div>
  );
}
