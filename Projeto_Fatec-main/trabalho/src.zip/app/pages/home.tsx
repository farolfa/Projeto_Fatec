import { Link } from "react-router";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import {
  Search,
  CheckCircle,
  Users,
  Star,
  Clock,
  Shield,
  Wrench,
  Sparkles,
  Zap,
  Droplet,
  Dumbbell,
  Paintbrush,
  Package,
  Scissors,
  Target,
  Eye,
  Heart,
} from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { useState } from "react";

const categories = [
  {
    name: "Reparos e Reformas",
    icon: Wrench,
    image: "https://images.unsplash.com/photo-1771122453274-d3270e73cf94?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBoYW5keW1hbiUyMHRvb2xzfGVufDF8fHx8MTc3MjQ4NzQ5MHww&ixlib=rb-4.1.0&q=80&w=1080",
    services: 150,
  },
  {
    name: "Limpeza",
    icon: Sparkles,
    image: "https://images.unsplash.com/photo-1581578949510-fa7315c4c350?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3VzZSUyMGNsZWFuaW5nJTIwc2VydmljZXxlbnwxfHx8fDE3NzI0MzQzNzB8MA&ixlib=rb-4.1.0&q=80&w=1080",
    services: 120,
  },
  {
    name: "Eletricista",
    icon: Zap,
    image: "https://images.unsplash.com/photo-1467733238130-bb6846885316?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVjdHJpY2lhbiUyMHdvcmtpbmclMjBwcm9mZXNzaW9uYWx8ZW58MXx8fHwxNzcyNDg1MjMzfDA&ixlib=rb-4.1.0&q=80&w=1080",
    services: 89,
  },
  {
    name: "Encanador",
    icon: Droplet,
    image: "https://images.unsplash.com/photo-1563197906-c1466d8e2edd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwbHVtYmVyJTIwZml4aW5nJTIwcGlwZXN8ZW58MXx8fHwxNzcyMzkwMTk0fDA&ixlib=rb-4.1.0&q=80&w=1080",
    services: 76,
  },
  {
    name: "Personal Trainer",
    icon: Dumbbell,
    image: "https://images.unsplash.com/photo-1518310383802-640c2de311b2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXJzb25hbCUyMHRyYWluZXIlMjBmaXRuZXNzfGVufDF8fHx8MTc3MjQ4NzQ5Mnww&ixlib=rb-4.1.0&q=80&w=1080",
    services: 65,
  },
  {
    name: "Pintura",
    icon: Paintbrush,
    image: "https://images.unsplash.com/photo-1688372199140-cade7ae820fe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYWludGluZyUyMGhvdXNlJTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc3MjQ4NzQ5Mnww&ixlib=rb-4.1.0&q=80&w=1080",
    services: 98,
  },
  {
    name: "Mudanças",
    icon: Package,
    image: "https://images.unsplash.com/photo-1746885434021-c6e3195a4ae8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3ZpbmclMjBzZXJ2aWNlcyUyMGJveGVzfGVufDF8fHx8MTc3MjQ4NzQ5M3ww&ixlib=rb-4.1.0&q=80&w=1080",
    services: 54,
  },
  {
    name: "Estética e Beleza",
    icon: Scissors,
    image: "https://images.unsplash.com/photo-1711274094763-ff442e4719ef?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZWF1dHklMjBzYWxvbiUyMG1hbmljdXJlfGVufDF8fHx8MTc3MjQ0MjQyNXww&ixlib=rb-4.1.0&q=80&w=1080",
    services: 142,
  },
];

const howItWorks = [
  {
    step: 1,
    title: "Descreva seu serviço",
    description: "Conte-nos o que você precisa em poucos minutos",
    icon: Search,
  },
  {
    step: 2,
    title: "Receba orçamentos",
    description: "Profissionais qualificados enviam propostas para você",
    icon: Users,
  },
  {
    step: 3,
    title: "Escolha o melhor",
    description: "Compare preços, avaliações e escolha quem contratar",
    icon: Star,
  },
  {
    step: 4,
    title: "Serviço realizado",
    description: "Acompanhe o trabalho e avalie o profissional",
    icon: CheckCircle,
  },
];

const stats = [
  { value: "500k+", label: "Serviços realizados" },
  { value: "50k+", label: "Profissionais cadastrados" },
  { value: "4.8/5", label: "Avaliação média" },
  { value: "24h", label: "Tempo médio de resposta" },
];

export function Home() {
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 text-white py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDE2djQuMDFIMjB2LTRoMTZ6bTAgOHY0LjAxSDIwdi00aDE2em0wIDh2NC4wMUgyMHYtNGgxNnoiLz48L2c+PC9nPjwvc3ZnPg==')] opacity-30"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-block mb-6">
              <span className="bg-orange-500 text-white px-4 py-2 rounded-full text-sm font-semibold uppercase tracking-wide shadow-lg">
                🚀 A Revolução dos Serviços Começou!
              </span>
            </div>
            <h1 className="text-5xl md:text-6xl lg:text-7xl mb-6 font-bold leading-tight">
              Seu serviço, <span className="text-orange-400">resolvido agora!</span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-blue-100">
              Conectamos você aos melhores profissionais em segundos.<br />
              <span className="text-orange-300 font-semibold">Rápido. Seguro. Garantido.</span>
            </p>

            {/* Search Bar */}
            <div className="bg-white rounded-xl p-2 flex flex-col sm:flex-row gap-2 shadow-2xl max-w-2xl mx-auto border-2 border-orange-400">
              <Input
                type="text"
                placeholder="Qual serviço você precisa AGORA?"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 border-none text-gray-900 text-lg"
              />
              <Link to="/solicitar-servico">
                <Button className="w-full sm:w-auto bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 px-8 py-6 text-lg font-semibold shadow-lg hover:shadow-xl transition-all">
                  <Search className="mr-2" size={20} />
                  Buscar Agora
                </Button>
              </Link>
            </div>

            {/* Popular Searches */}
            <div className="mt-6 flex flex-wrap justify-center gap-2">
              <span className="text-blue-200 text-sm font-medium">🔥 Mais procurados:</span>
              {["Eletricista", "Encanador", "Limpeza", "Pintura"].map(
                (term) => (
                  <button
                    key={term}
                    className="text-sm bg-white/20 hover:bg-white/30 backdrop-blur-sm px-4 py-2 rounded-full transition-all font-medium border border-white/30"
                  >
                    {term}
                  </button>
                )
              )}
            </div>

            {/* Quick Access to Dashboard */}
            <div className="mt-8 p-4 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20">
              <p className="text-sm text-blue-100 mb-2">Já é cliente?</p>
              <Link to="/dashboard">
                <Button
                  variant="outline"
                  className="bg-white text-blue-600 hover:bg-blue-50 border-none w-full sm:w-auto"
                >
                  Acessar Minha Conta →
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-gradient-to-r from-orange-50 to-blue-50 border-b-4 border-orange-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 to-orange-500 bg-clip-text text-transparent mb-2">
                  {stat.value}
                </div>
                <div className="text-gray-700 text-sm md:text-base font-medium">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission, Vision, Values Section */}
      <section className="py-20 bg-gradient-to-br from-blue-600 via-blue-700 to-blue-900 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wMyI+PHBhdGggZD0iTTM2IDE2djQuMDFIMjB2LTRoMTZ6bTAgOHY0LjAxSDIwdi00aDE2em0wIDh2NC4wMUgyMHYtNGgxNnoiLz48L2c+PC9nPjwvc3ZnPg==')] opacity-50"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Quem Somos
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-orange-400 to-orange-600 mx-auto rounded-full"></div>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {/* Missão */}
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border-2 border-white/20 hover:border-orange-400 transition-all shadow-xl hover:shadow-2xl">
              <div className="bg-gradient-to-br from-orange-400 to-orange-600 w-16 h-16 rounded-2xl flex items-center justify-center mb-6 shadow-lg">
                <Target className="text-white" size={32} />
              </div>
              <h3 className="text-2xl font-bold mb-4 text-orange-300">Missão</h3>
              <p className="text-blue-100 leading-relaxed">
                Conectar pessoas e profissionais com eficiência, segurança e inovação, transformando necessidades em soluções de qualidade.
              </p>
            </div>

            {/* Visão */}
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border-2 border-white/20 hover:border-orange-400 transition-all shadow-xl hover:shadow-2xl">
              <div className="bg-gradient-to-br from-blue-400 to-blue-600 w-16 h-16 rounded-2xl flex items-center justify-center mb-6 shadow-lg">
                <Eye className="text-white" size={32} />
              </div>
              <h3 className="text-2xl font-bold mb-4 text-blue-300">Visão</h3>
              <p className="text-blue-100 leading-relaxed">
                Ser referência nacional na intermediação de serviços, liderando a transformação do setor com crescimento sustentável e excelência.
              </p>
            </div>

            {/* Valores */}
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border-2 border-white/20 hover:border-orange-400 transition-all shadow-xl hover:shadow-2xl">
              <div className="bg-gradient-to-br from-orange-400 to-orange-600 w-16 h-16 rounded-2xl flex items-center justify-center mb-6 shadow-lg">
                <Heart className="text-white" size={32} />
              </div>
              <h3 className="text-2xl font-bold mb-4 text-orange-300">Valores</h3>
              <p className="text-blue-100 leading-relaxed">
                Atuamos com ética, transparência e compromisso com resultados, valorizando pessoas, inovação e a busca contínua pela liderança.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl text-center mb-12">
            Categorias de Serviços
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.map((category) => (
              <Link
                key={category.name}
                to="/solicitar-servico"
                className="group relative overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 aspect-square"
              >
                <ImageWithFallback
                  src={category.image}
                  alt={category.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent flex flex-col justify-end p-4">
                  <category.icon className="text-white mb-2" size={32} />
                  <h3 className="text-white text-xl mb-1">
                    {category.name}
                  </h3>
                  <p className="text-gray-300 text-sm">
                    {category.services} profissionais
                  </p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl md:text-5xl text-center mb-4 font-bold">
            Como Funciona
          </h2>
          <p className="text-center text-gray-600 mb-12 max-w-2xl mx-auto text-lg">
            Em apenas <span className="text-orange-600 font-bold">4 passos simples</span> você encontra o profissional perfeito
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {howItWorks.map((item) => (
              <div key={item.step} className="text-center group">
                <div className="bg-gradient-to-br from-blue-600 to-blue-700 text-white w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-4 text-3xl font-bold shadow-lg group-hover:shadow-2xl group-hover:scale-110 transition-all">
                  {item.step}
                </div>
                <item.icon
                  className="text-orange-500 mx-auto mb-4 group-hover:scale-110 transition-transform"
                  size={48}
                />
                <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                <p className="text-gray-600">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center p-8 bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl hover:shadow-xl transition-shadow">
              <div className="bg-gradient-to-br from-blue-500 to-blue-700 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                <Clock className="text-white" size={40} />
              </div>
              <h3 className="text-2xl font-bold mb-3">Rápido e Fácil</h3>
              <p className="text-gray-600 text-lg">
                Receba orçamentos em até 24 horas e escolha o melhor para você
              </p>
            </div>
            <div className="text-center p-8 bg-gradient-to-br from-orange-50 to-orange-100 rounded-2xl hover:shadow-xl transition-shadow">
              <div className="bg-gradient-to-br from-orange-500 to-orange-700 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                <Shield className="text-white" size={40} />
              </div>
              <h3 className="text-2xl font-bold mb-3">Seguro e Confiável</h3>
              <p className="text-gray-600 text-lg">
                Todos os profissionais são verificados e avaliados por outros
                clientes
              </p>
            </div>
            <div className="text-center p-8 bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl hover:shadow-xl transition-shadow">
              <div className="bg-gradient-to-br from-blue-500 to-blue-700 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                <Star className="text-white" size={40} />
              </div>
              <h3 className="text-2xl font-bold mb-3">Melhor Custo-Benefício</h3>
              <p className="text-gray-600 text-lg">
                Compare orçamentos e escolha a melhor opção para o seu bolso
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA for Professionals */}
      <section className="py-20 bg-gradient-to-br from-orange-500 via-orange-600 to-orange-700 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMTZ2NC4wMUgyMHYtNGgxNnptMCA4djQuMDFIMjB2LTRoMTZ6bTAgOHY0LjAxSDIwdi00aDE2eiIvPjwvZz48L2c+PC9zdmc+')] opacity-30"></div>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <div className="inline-block mb-6">
            <span className="bg-white text-orange-600 px-4 py-2 rounded-full text-sm font-semibold uppercase tracking-wide shadow-lg">
              💼 Oportunidade de Ouro
            </span>
          </div>
          <h2 className="text-4xl md:text-5xl mb-6 font-bold">
            É um profissional?<br />
            <span className="text-orange-200">Multiplique seus ganhos!</span>
          </h2>
          <p className="text-xl md:text-2xl mb-8 text-orange-100">
            Cadastre-se <span className="font-bold text-white">100% GRÁTIS</span> e receba pedidos na sua região todos os dias
          </p>
          <Link to="/seja-profissional">
            <Button
              size="lg"
              className="bg-white text-orange-600 hover:bg-orange-50 px-10 py-7 text-xl font-bold shadow-2xl hover:shadow-3xl hover:scale-105 transition-all"
            >
              Quero Aumentar Minha Renda Agora! 🚀
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}