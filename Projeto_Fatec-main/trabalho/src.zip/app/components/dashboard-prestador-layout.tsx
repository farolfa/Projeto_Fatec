import { Outlet, Link, useLocation } from "react-router";
import { Button } from "./ui/button";
import {
  Briefcase,
  TrendingUp,
  Send,
  User,
  LogOut,
  Menu,
  X,
  RefreshCw,
} from "lucide-react";
import { useState } from "react";
import { Badge } from "./ui/badge";

const navItems = [
  {
    path: "/prestador",
    label: "Painel",
    icon: Briefcase,
  },
  {
    path: "/prestador/servicos-disponiveis",
    label: "Serviços Disponíveis",
    icon: TrendingUp,
    badge: 15,
  },
  {
    path: "/prestador/minhas-propostas",
    label: "Minhas Propostas",
    icon: Send,
    badge: 4,
  },
  {
    path: "/prestador/perfil",
    label: "Meu Perfil",
    icon: User,
  },
];

export function DashboardPrestadorLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Bar */}
      <header className="bg-white border-b sticky top-0 z-50 shadow-sm">
        <div className="px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center gap-4">
              <button
                className="lg:hidden"
                onClick={() => setSidebarOpen(!sidebarOpen)}
              >
                {sidebarOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
              <Link to="/" className="flex items-center gap-2">
                <div className="bg-gradient-to-r from-blue-600 to-orange-500 text-white px-4 py-2 rounded-lg font-bold text-lg shadow-md hover:shadow-lg transition-shadow">
                  FazTudoJA
                </div>
                <Badge className="bg-orange-100 text-orange-800 border-orange-300">
                  Prestador
                </Badge>
              </Link>
            </div>

            {/* Right Side */}
            <div className="flex items-center gap-4">
              <Link to="/dashboard">
                <Button
                  size="sm"
                  variant="outline"
                  className="border-blue-600 text-blue-600 hover:bg-blue-50 hidden sm:flex"
                >
                  <RefreshCw size={16} className="mr-2" />
                  Área do Cliente
                </Button>
              </Link>

              <Link to="/">
                <Button variant="ghost" size="sm">
                  <LogOut size={20} />
                  <span className="ml-2 hidden sm:inline">Sair</span>
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside
          className={`${
            sidebarOpen ? "translate-x-0" : "-translate-x-full"
          } lg:translate-x-0 fixed lg:static inset-y-0 left-0 z-40 w-64 bg-white border-r transition-transform duration-300 ease-in-out mt-16 lg:mt-0`}
        >
          <nav className="p-4 space-y-1 h-[calc(100vh-64px)] overflow-y-auto">
            {/* Switch to Client Mode */}
            <Link to="/dashboard" onClick={() => setSidebarOpen(false)}>
              <div className="mb-4 p-3 bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg border-2 border-blue-200 hover:border-blue-400 transition-all">
                <div className="flex items-center gap-2 text-sm font-medium text-blue-700">
                  <RefreshCw size={16} />
                  <span>Trocar para Área Cliente</span>
                </div>
              </div>
            </Link>

            {navItems.map((item) => (
              <Link key={item.path} to={item.path} onClick={() => setSidebarOpen(false)}>
                <div
                  className={`flex items-center justify-between px-4 py-3 rounded-lg transition-all ${
                    isActive(item.path)
                      ? "bg-gradient-to-r from-orange-500 to-orange-600 text-white shadow-md"
                      : "hover:bg-gray-100 text-gray-700"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <item.icon size={20} />
                    <span className="font-medium">{item.label}</span>
                  </div>
                  {item.badge && !isActive(item.path) && (
                    <Badge className="bg-blue-500 text-white">
                      {item.badge}
                    </Badge>
                  )}
                </div>
              </Link>
            ))}
          </nav>
        </aside>

        {/* Overlay for mobile */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 bg-black/50 z-30 lg:hidden mt-16"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Main Content */}
        <main className="flex-1 min-h-[calc(100vh-64px)]">
          <Outlet />
        </main>
      </div>
    </div>
  );
}