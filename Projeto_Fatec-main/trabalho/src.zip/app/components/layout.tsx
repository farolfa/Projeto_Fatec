import { Outlet, Link, useLocation } from "react-router";
import { Button } from "./ui/button";
import { Menu, X } from "lucide-react";
import { useState } from "react";

export function Layout() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center">
              <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-5 py-2.5 rounded-lg font-bold text-xl shadow-lg hover:shadow-xl transition-shadow">
                FazTudoJA
              </div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-8">
              <Link
                to="/"
                className={`hover:text-blue-600 transition-colors ${
                  isActive("/") ? "text-blue-600" : "text-gray-700"
                }`}
              >
                Início
              </Link>
              <Link
                to="/solicitar-servico"
                className={`hover:text-blue-600 transition-colors ${
                  isActive("/solicitar-servico") ? "text-blue-600" : "text-gray-700"
                }`}
              >
                Solicitar Serviço
              </Link>
              <Link
                to="/seja-profissional"
                className="text-gray-700 hover:text-blue-600 transition-colors"
              >
                Para Profissionais
              </Link>
            </nav>

            {/* Desktop CTA */}
            <div className="hidden md:flex items-center gap-4">
              <Link to="/dashboard">
                <Button 
                  size="sm"
                  className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white shadow-md"
                >
                  👤 Área do Cliente
                </Button>
              </Link>
              <Link to="/prestador">
                <Button 
                  size="sm"
                  className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white shadow-md"
                >
                  💼 Área do Prestador
                </Button>
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden py-4 space-y-4">
              <Link
                to="/"
                className="block py-2 text-gray-700 hover:text-blue-600"
                onClick={() => setMobileMenuOpen(false)}
              >
                Início
              </Link>
              <Link
                to="/solicitar-servico"
                className="block py-2 text-gray-700 hover:text-blue-600"
                onClick={() => setMobileMenuOpen(false)}
              >
                Solicitar Serviço
              </Link>
              <Link
                to="/seja-profissional"
                className="block py-2 text-gray-700 hover:text-blue-600"
                onClick={() => setMobileMenuOpen(false)}
              >
                Para Profissionais
              </Link>
              <div className="flex flex-col gap-2 pt-4">
                <Button variant="outline" className="w-full border-blue-600 text-blue-600 hover:bg-blue-50">
                  Entrar
                </Button>
                <Button className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700">
                  Cadastrar
                </Button>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-5 py-2.5 rounded-lg font-bold text-xl inline-block mb-4 shadow-lg">
                FazTudoJA
              </div>
              <p className="text-gray-400 text-sm">
                Conectando você aos melhores profissionais
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Para Clientes</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link to="/solicitar-servico" className="hover:text-white">
                    Solicitar Serviço
                  </Link>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Como Funciona
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Avaliações
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Para Profissionais</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link to="/seja-profissional" className="hover:text-white">
                    Cadastre-se
                  </Link>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Vantagens
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    FAQ
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Contato</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <a href="#" className="hover:text-white">
                    Suporte
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Termos de Uso
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Privacidade
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400 text-sm">
            <p>&copy; 2026 FazTudoJA. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}