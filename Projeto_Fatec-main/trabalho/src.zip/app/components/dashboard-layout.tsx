import { Outlet, Link, useLocation } from "react-router";
import { Button } from "./ui/button";
import {
  LayoutDashboard,
  FileText,
  MessageSquare,
  User,
  Bell,
  Star,
  LogOut,
  Menu,
  X,
  DollarSign,
  RefreshCw,
} from "lucide-react";
import { useState } from "react";
import { Badge } from "./ui/badge";

const navItems = [
  {
    path: "/dashboard",
    label: "Painel",
    icon: LayoutDashboard,
  },
  {
    path: "/dashboard/meus-pedidos",
    label: "Meus Pedidos",
    icon: FileText,
  },
  {
    path: "/dashboard/orcamentos",
    label: "Orçamentos",
    icon: DollarSign,
    badge: 8,
  },
  {
    path: "/dashboard/mensagens",
    label: "Mensagens",
    icon: MessageSquare,
    badge: 3,
  },
  {
    path: "/dashboard/notificacoes",
    label: "Notificações",
    icon: Bell,
    badge: 3,
  },
  {
    path: "/dashboard/avaliacoes",
    label: "Avaliações",
    icon: Star,
    badge: 1,
  },
  {
    path: "/dashboard/perfil",
    label: "Perfil",
    icon: User,
  },
];

export function DashboardLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Bar */}
      <header className="bg-white border-b sticky top-0 z-50 shadow-sm">
        <div className="px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center gap-4">
              <button
                className="lg:hidden"
                onClick={() => setSidebarOpen(!sidebarOpen)}
              >
                {sidebarOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
              <Link to="/" className="flex items-center gap-2">
                <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-4 py-2 rounded-lg font-bold text-lg shadow-md hover:shadow-lg transition-shadow">
                  FazTudoJA
                </div>
                <Badge className="bg-blue-100 text-blue-800 border-blue-300">
                  Cliente
                </Badge>
              </Link>
            </div>

            {/* Right Side */}
            <div className="flex items-center gap-4">
              <Link to="/solicitar-servico">
                <Button
                  size="sm"
                  className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 shadow-md hidden sm:flex"
                >
                  + Novo Pedido
                </Button>
              </Link>
              
              <Link to="/prestador">
                <Button
                  size="sm"
                  variant="outline"
                  className="border-orange-600 text-orange-600 hover:bg-orange-50 hidden sm:flex"
                >
                  <RefreshCw size={16} className="mr-2" />
                  Área do Prestador
                </Button>
              </Link>
              
              <Link to="/dashboard/notificacoes" className="relative">
                <Button variant="ghost" size="sm" className="relative">
                  <Bell size={20} />
                  <Badge className="absolute -top-1 -right-1 bg-red-500 text-white text-xs px-1.5 min-w-[20px] h-5 flex items-center justify-center">
                    3
                  </Badge>
                </Button>
              </Link>

              <Link to="/">
                <Button variant="ghost" size="sm">
                  <LogOut size={20} />
                  <span className="ml-2 hidden sm:inline">Sair</span>
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside
          className={`${
            sidebarOpen ? "translate-x-0" : "-translate-x-full"
          } lg:translate-x-0 fixed lg:static inset-y-0 left-0 z-40 w-64 bg-white border-r transition-transform duration-300 ease-in-out mt-16 lg:mt-0`}
        >
          <nav className="p-4 space-y-1 h-[calc(100vh-64px)] overflow-y-auto">
            {/* Switch to Professional Mode */}
            <Link to="/prestador" onClick={() => setSidebarOpen(false)}>
              <div className="mb-4 p-3 bg-gradient-to-r from-orange-50 to-orange-100 rounded-lg border-2 border-orange-200 hover:border-orange-400 transition-all">
                <div className="flex items-center gap-2 text-sm font-medium text-orange-700">
                  <RefreshCw size={16} />
                  <span>Trocar para Área Prestador</span>
                </div>
              </div>
            </Link>

            {navItems.map((item) => (
              <Link key={item.path} to={item.path} onClick={() => setSidebarOpen(false)}>
                <div
                  className={`flex items-center justify-between px-4 py-3 rounded-lg transition-all ${
                    isActive(item.path)
                      ? "bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-md"
                      : "hover:bg-gray-100 text-gray-700"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <item.icon size={20} />
                    <span className="font-medium">{item.label}</span>
                  </div>
                  {item.badge && !isActive(item.path) && (
                    <Badge className="bg-orange-500 text-white">
                      {item.badge}
                    </Badge>
                  )}
                </div>
              </Link>
            ))}
          </nav>
        </aside>

        {/* Overlay for mobile */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 bg-black/50 z-30 lg:hidden mt-16"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Main Content */}
        <main className="flex-1 min-h-[calc(100vh-64px)]">
          <Outlet />
        </main>
      </div>
    </div>
  );
}