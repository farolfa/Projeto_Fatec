import { createBrowserRouter } from "react-router";
import { Layout } from "./components/layout";
import { DashboardLayout } from "./components/dashboard-layout";
import { DashboardPrestadorLayout } from "./components/dashboard-prestador-layout";
import { Home } from "./pages/home";
import { RequestService } from "./pages/request-service";
import { BecomeProfessional } from "./pages/become-professional";
import { Dashboard } from "./pages/dashboard";
import { MeusPedidos } from "./pages/meus-pedidos";
import { Orcamentos } from "./pages/orcamentos";
import { Mensagens } from "./pages/mensagens";
import { Notificacoes } from "./pages/notificacoes";
import { Avaliacoes } from "./pages/avaliacoes";
import { Perfil } from "./pages/perfil";
import { DashboardPrestador } from "./pages/prestador/dashboard-prestador";
import { ServicosDisponiveis } from "./pages/prestador/servicos-disponiveis";
import { MinhasPropostas } from "./pages/prestador/minhas-propostas";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Home },
      { path: "solicitar-servico", Component: RequestService },
      { path: "seja-profissional", Component: BecomeProfessional },
    ],
  },
  {
    path: "/dashboard",
    Component: DashboardLayout,
    children: [
      { index: true, Component: Dashboard },
      { path: "meus-pedidos", Component: MeusPedidos },
      { path: "orcamentos", Component: Orcamentos },
      { path: "mensagens", Component: Mensagens },
      { path: "notificacoes", Component: Notificacoes },
      { path: "avaliacoes", Component: Avaliacoes },
      { path: "perfil", Component: Perfil },
    ],
  },
  {
    path: "/prestador",
    Component: DashboardPrestadorLayout,
    children: [
      { index: true, Component: DashboardPrestador },
      { path: "servicos-disponiveis", Component: ServicosDisponiveis },
      { path: "minhas-propostas", Component: MinhasPropostas },
      { path: "perfil", Component: Perfil },
    ],
  },
]);